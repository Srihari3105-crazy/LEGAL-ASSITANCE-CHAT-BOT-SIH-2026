export type PageId = 
  | 'landing'
  | 'dashboard'
  | 'chat'
  | 'laws'
  | 'schemes'
  | 'pmfby'
  | 'grievance'
  | 'financial'
  | 'pacs'
  | 'voice'
  | 'admin';

export type UserRole = 'farmer' | 'pacs_admin' | 'officer' | 'super_admin' | 'kiosk_operator';

export type LanguageCode = 
  | 'en' // English
  | 'hi' // Hindi
  | 'ta' // Tamil
  | 'te' // Telugu
  | 'bn' // Bengali
  | 'mr' // Marathi
  | 'gu' // Gujarati
  | 'kn' // Kannada
  | 'ml' // Malayalam
  | 'pa' // Punjabi
  | 'or' // Odia
  | 'ur'; // Urdu

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  nativeName: string;
  script: string;
  bcp47: string;
  dir?: 'ltr' | 'rtl';
}

export interface LawItem {
  id: string;
  act: string;
  section: string;
  category: string;
  importance: 'High' | 'Medium' | 'Standard';
  lastAmended: string;
  stateApplicability: string;
  title: string;
  titleHi?: string;
  summary: string;
  summaryHi?: string;
  keyProvisions: string[];
  keyProvisionsHi?: string[];
  penalty?: string;
  penaltyHi?: string;
}

export interface SchemeItem {
  id: string;
  ministry: string;
  category: string;
  targetGroup: ('farmer' | 'pacs' | 'women' | 'youth' | 'society')[];
  subsidyAmount: string;
  subsidyAmountHi?: string;
  status: string;
  deadline: string;
  stateApplicability: string;
  title: string;
  titleHi?: string;
  benefits: string[];
  benefitsHi?: string[];
  eligibilityCriteria: string[];
  eligibilityCriteriaHi?: string[];
  requiredDocs: string[];
  requiredDocsHi?: string[];
}

export interface GrievanceRecord {
  id: string;
  category: string;
  complainantName: string;
  mobile: string;
  societyName: string;
  district: string;
  state: string;
  dateFiled: string;
  status: 'Received' | 'Under Investigation' | 'Hearing Scheduled' | 'Resolved';
  priority: 'Urgent' | 'Standard' | 'Escalated';
  description: string;
  slaRemainingDays: number;
  assignedOfficer: string;
  timeline: {
    stage: string;
    date: string;
    remarks: string;
    completed: boolean;
  }[];
}

export interface PACSService {
  id: string;
  category: string;
  iconName: string;
  title: string;
  titleHi?: string;
  description: string;
  descriptionHi?: string;
  processingTime: string;
  processingTimeHi?: string;
  subsidyOrFee: string;
  subsidyOrFeeHi?: string;
  requiredDocuments: string[];
  requiredDocumentsHi?: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  language: LanguageCode;
  timestamp: string;
  citations?: {
    act: string;
    section: string;
    clause: string;
    title: string;
  }[];
  confidence?: number;
  suggestedActions?: string[];
  audioPlaying?: boolean;
}

export interface PMFBYCalculation {
  state: string;
  district: string;
  crop: string;
  season: 'Kharif' | 'Rabi' | 'Commercial / Horticultural';
  areaAcres: number;
  sumInsuredPerAcre: number;
  farmerRatePercent: number;
  totalSumInsured: number;
  farmerPremium: number;
  centralSubsidy: number;
  stateSubsidy: number;
  totalPremium: number;
}
