import { LawItem, SchemeItem, GrievanceRecord, PACSService, ChatMessage } from '../types';

export const COOPERATIVE_LAWS: LawItem[] = [
  {
    id: 'law-1',
    act: 'Multi-State Co-operative Societies (Amendment) Act, 2023',
    section: 'Section 29 & 45',
    title: 'Cooperative Election Authority & Democratic Governance',
    titleHi: 'सहकारी निर्वाचन प्राधिकरण एवं लोकतांत्रिक शासन',
    category: 'MSCS Amendment 2023',
    importance: 'High',
    lastAmended: 'August 2023',
    stateApplicability: 'All Multi-State Societies (National)',
    summary: 'Establishes an independent Cooperative Election Authority (CEA) to conduct fair and timely elections, mandating representation for Women (at least 2 seats) and SC/ST members on the Board.',
    summaryHi: 'निष्पक्ष और समय पर चुनाव कराने के लिए स्वतंत्र सहकारी निर्वाचन प्राधिकरण (CEA) की स्थापना करता है, जिसमें बोर्ड में महिलाओं (कम से कम 2 सीटें) और अनुसूचित जाति/जनजाति के सदस्यों के लिए अनिवार्य प्रतिनिधित्व है।',
    keyProvisions: [
      'Establishment of independent Cooperative Election Authority appointed by Central Govt.',
      'Mandatory 2 women directors and 1 SC/ST director on the Board of every multi-state cooperative.',
      'Disqualification for board members who fail to conduct AGM or produce audited accounts for 2 consecutive years.',
      'Right of active members to inspect electoral rolls 30 days prior to election date.'
    ],
    penalty: 'Disqualification of board for up to 5 years and fine up to ₹1,00,000 for obstructing fair elections.'
  },
  {
    id: 'law-2',
    act: 'Model Bye-Laws for Primary Agricultural Credit Societies (PACS), 2023',
    section: 'Clause 4 & 18',
    title: 'Multipurpose PACS Transformation & 25+ Business Activities',
    titleHi: 'बहुउद्देशीय पैक्स रूपांतरण एवं 25+ व्यावसायिक गतिविधियां',
    category: 'Model PACS Bye-Laws',
    importance: 'High',
    lastAmended: 'January 2023',
    stateApplicability: 'Adopted by 30+ States/UTs',
    summary: 'Empowers PACS to diversify beyond traditional credit into 25+ commercial activities including fertilizers, seeds, custom hiring of farm machinery/drones, Jan Aushadhi Kendras, LPG distributorship, and CSC digital services.',
    summaryHi: 'पैक्स (PACS) को पारंपरिक ऋण के अलावा 25+ व्यावसायिक गतिविधियों जैसे उर्वरक, बीज, कृषि ड्रोन/मशीनरी कस्टम हायरिंग, जन औषधि केंद्र, एलपीजी वितरण और सीएससी डिजिटल सेवाओं में विविधता लाने का अधिकार देता है।',
    keyProvisions: [
      'PACS can establish Common Service Centres (CSC) for over 300 e-governance services.',
      'Authority to operate decentralized grain storage facilities up to 2,000 MT under NABARD assistance.',
      'Permission to retail affordable generic medicines through Pradhan Mantri Bhartiya Janaushadhi Pariyojana.',
      'Direct tie-up with Oil Marketing Companies (OMCs) for retail LPG and petrol pump outlets.'
    ],
    penalty: 'Non-adoption delays grant eligibility under ₹2,516 Crore PACS Computerization Scheme.'
  },
  {
    id: 'law-3',
    act: 'Multi-State Co-operative Societies Act, 2002 (as amended 2023)',
    section: 'Section 84 & 85',
    title: 'Cooperative Ombudsman & Member Grievance Redressal',
    titleHi: 'सहकारी लोकपाल एवं सदस्य शिकायत निवारण प्रणाली',
    category: 'MSCS Act 2002',
    importance: 'High',
    lastAmended: '2023',
    stateApplicability: 'All Multi-State Societies',
    summary: 'Mandates appointment of Cooperative Information Officers and Ombudsman for time-bound resolution of member disputes, wrongful expulsion, or withheld dividends within 30 days.',
    summaryHi: 'सदस्यों के विवादों, गलत निष्कासन या रोके गए लाभांश के 30 दिनों के भीतर समयबद्ध समाधान के लिए सहकारी सूचना अधिकारी और लोकपाल की नियुक्ति को अनिवार्य करता है।',
    keyProvisions: [
      'Every member has a legal right to receive audited financial statements within 15 days of AGM.',
      'Central Registrar or Ombudsman must adjudicate complaints within 30 working days.',
      'Protection for whistleblowers reporting financial fraud or vote buying in cooperative elections.'
    ],
    penalty: 'Compensation to aggrieved member up to ₹50,000 payable by the defaulting society officer.'
  },
  {
    id: 'law-4',
    act: 'State Cooperative Societies Acts (Comparative Standard)',
    section: 'Section 19 & 27',
    title: 'Open Membership & Voting Rights of Small/Marginal Farmers',
    titleHi: 'खुली सदस्यता एवं छोटे/सीमांत किसानों के मतदान अधिकार',
    category: 'Member Rights & Duties',
    importance: 'Standard',
    lastAmended: '2022-2024 State Revisions',
    stateApplicability: 'Universal across Indian States',
    summary: 'Guarantees "One Member, One Vote" regardless of share capital size. Disallows cooperative management from arbitrarily denying membership to any eligible farmer residing in the area of operation.',
    summaryHi: 'शेयर पूंजी के आकार की परवाह किए बिना "एक सदस्य, एक वोट" की गारंटी देता है। सहकारी प्रबंधन को कार्यक्षेत्र में रहने वाले किसी भी पात्र किसान को सदस्यता से मनमाने ढंग से इनकार करने से रोकता है।',
    keyProvisions: [
      'Deemed membership if society fails to decide on application within 60 days.',
      'Voting right active upon completion of minimum transactions in the preceding cooperative year.',
      'Equal access to subsidized fertilizers, seeds, and short-term crop loans.'
    ]
  },
  {
    id: 'law-5',
    act: 'National Cooperative Policy Framework, 2024',
    section: 'Pillar III: Transparency & Audit',
    title: 'Mandatory Concurrent Audit & National Cooperative Database Integration',
    titleHi: 'अनिवार्य समवर्ती लेखापरीक्षा एवं राष्ट्रीय सहकारी डेटाबेस एकीकरण',
    category: 'National Cooperative Policy',
    importance: 'High',
    lastAmended: '2024',
    stateApplicability: 'All Cooperative Sectors',
    summary: 'Requires all PACS, Dairy, and Fisheries cooperatives to upload audited financial data to the National Cooperative Database (NCD) for transparency and direct benefit transfer.',
    summaryHi: 'पारदर्शिता और प्रत्यक्ष लाभ अंतरण के लिए सभी पैक्स, डेयरी और मत्स्य सहकारी समितियों को राष्ट्रीय सहकारी डेटाबेस (NCD) पर लेखापरीक्षित वित्तीय डेटा अपलोड करना अनिवार्य करता है।',
    keyProvisions: [
      'Standardized Chart of Accounts across 1,00,000+ PACS in India.',
      'Zero manual balance sheets; single national ERP software integration.',
      'Real-time tracking of fertilizer supply from factory to farmer.'
    ]
  },
  {
    id: 'law-6',
    act: 'Multi-State Co-operative Societies Act',
    section: 'Section 63 & 70',
    title: 'Cooperative Rehabilitation, Reconstruction & Development Fund',
    titleHi: 'सहकारी पुनर्वास, पुनर्निर्माण एवं विकास कोष',
    category: 'MSCS Act 2002',
    importance: 'Standard',
    lastAmended: '2023',
    stateApplicability: 'Multi-State Societies',
    summary: 'Institutes a statutory non-lapsable fund funded by profitable societies (1% of net profits) to revive sick or financially distressed cooperative societies.',
    summaryHi: 'बीमार या वित्तीय रूप से संकटग्रस्त सहकारी समितियों को पुनर्जीवित करने के लिए लाभदायक समितियों द्वारा वित्तपोषित एक वैधानिक कोष की स्थापना करता है।',
    keyProvisions: [
      '1% of net annual profit contribution by profit-making MSCS.',
      'Emergency liquidity support to societies impacted by natural disasters.'
    ]
  }
];

export const GOVT_SCHEMES: SchemeItem[] = [
  {
    id: 'sch-1',
    title: 'Computerization of Primary Agricultural Credit Societies (PACS)',
    titleHi: 'प्राथमिक कृषि साख समितियों (PACS) का कम्प्यूटरीकरण',
    ministry: 'Ministry of Cooperation, GoI',
    category: 'Digitization',
    targetGroup: ['pacs', 'farmer'],
    subsidyAmount: '100% Grant (Total Outlay: ₹2,516 Crore for 63,000+ PACS)',
    benefits: [
      'Cloud-based national ERP software in local regional languages.',
      'Direct integration with NABARD, DCCB, and State Cooperative Banks.',
      'Eliminates accounting delays and provides instant KCC loan sanctioning.',
      'Automated SMS alerts to farmer members on deposit, loan, and fertilizer quota.'
    ],
    eligibilityCriteria: [
      'Registered PACS affiliated with a District Central Cooperative Bank (DCCB).',
      'Commitment to adopt Model Bye-Laws 2023.',
      'Minimum of 100 active borrower members.'
    ],
    requiredDocs: [
      'Society Registration Certificate',
      'Audit Report of Last 3 Years',
      'Resolution passed by PACS Board',
      'List of Active Members with Aadhaar linkage'
    ],
    status: 'Active / Open',
    deadline: 'Rolling Implementation across all Districts',
    stateApplicability: 'Pan-India (All 28 States & UTs)'
  },
  {
    id: 'sch-2',
    title: "World's Largest Grain Storage Plan in Cooperative Sector",
    titleHi: 'सहकारी क्षेत्र में विश्व की सबसे बड़ी अनाज भंडारण योजना',
    ministry: 'Ministry of Cooperation (Inter-Ministerial with Agri & Food)',
    category: 'Infrastructure',
    targetGroup: ['pacs', 'farmer', 'society'],
    subsidyAmount: 'Up to 100% converged financial assistance (AIF, AMI, PMKSY)',
    benefits: [
      'Construction of 500 MT to 2,000 MT decentralized godowns at PACS level.',
      'Allows farmers to store harvested produce and prevent distress sales.',
      'Farmers get electronic Negotiable Warehouse Receipts (e-NWR) to pledge for instant bank loans (up to 70% value).',
      'Reduces post-harvest wastage and eliminates long travel to APMC mandis.'
    ],
    eligibilityCriteria: [
      'PACS owning or leasing minimum 0.5 to 1 acre of land near motorable road.',
      'Affiliation with local agricultural mandis or State Civil Supplies Corporation.',
      'No critical financial default in the last audit.'
    ],
    requiredDocs: [
      'Land Title / 30-Year Registered Lease Deed',
      'Soil Suitability & Geo-Coordinates Certificate',
      'Board Resolution approved by General Body',
      'DCCB / State Cooperative Bank NOC'
    ],
    status: 'Ongoing',
    deadline: 'Phase-I (1,000 PACS pilot) expanding to 100,000 PACS',
    stateApplicability: 'All States with agricultural surplus'
  },
  {
    id: 'sch-3',
    title: 'Sahkar-se-Samriddhi Scheme & Dairy/Fisheries PACS Formation',
    titleHi: 'सहकार से समृद्धि: प्रत्येक पंचायत में पैक्स/डेयरी/मत्स्य समिति',
    ministry: 'Ministry of Cooperation',
    category: 'Credit & Finance',
    targetGroup: ['farmer', 'women', 'youth', 'society'],
    subsidyAmount: 'Seed Capital ₹5-15 Lakhs + Margin Money Assistance',
    benefits: [
      'Target: Setting up 2,00,000 new viable Multipurpose PACS, Dairy, and Fishery societies.',
      'Ensures every Gram Panchayat has at least one functional cooperative entity.',
      'Direct linkage of dairy farmers to National Dairy Development Board (NDDB) bulk milk coolers.',
      'Women SHG members prioritized for cooperative leadership.'
    ],
    eligibilityCriteria: [
      'Panchayats with no existing functional PACS or Dairy cooperative.',
      'Minimum 25 promoter members from the village (at least 30% women).',
      'Villagers engaged in farming, animal husbandry, or inland fishing.'
    ],
    requiredDocs: [
      'Promoter Members List with Voter ID / Aadhaar',
      'Gram Sabha Resolution',
      'Initial Share Capital Deposit Slip'
    ],
    status: 'Active / Open',
    deadline: 'Target completion by 2027',
    stateApplicability: 'Pan-India'
  },
  {
    id: 'sch-4',
    title: 'NCCT National Cooperative Training & Skill Development',
    titleHi: 'NCCT राष्ट्रीय सहकारी प्रशिक्षण एवं कौशल विकास कार्यक्रम',
    ministry: 'National Council for Cooperative Training (NCCT)',
    category: 'Training & Capacity',
    targetGroup: ['youth', 'women', 'pacs'],
    subsidyAmount: '100% Free Training + Daily Stipend for Rural Trainees',
    benefits: [
      'Certified diplomas in PACS Management, Agri-Drone Operation, and Cooperative Accounting.',
      'Specialized modules for Women Self-Help Groups on value addition and organic packaging.',
      'Placement support across District Central Cooperative Banks and Cooperative Federations.'
    ],
    eligibilityCriteria: [
      'Age between 18 to 45 years.',
      'Minimum 10th standard pass for drone/machinery, 12th/Graduate for Accounts.',
      'Resident of rural/semi-urban district.'
    ],
    requiredDocs: [
      'Educational Certificates',
      'Aadhaar Card',
      'Recommendation from local PACS or Gram Pradhan'
    ],
    status: 'Active / Open',
    deadline: 'Batches start 1st of every month',
    stateApplicability: 'All State Institutes of Cooperative Management (RICMs/ICMs)'
  },
  {
    id: 'sch-5',
    title: 'Pradhan Mantri Fasal Bima Yojana (PMFBY) Co-op Window',
    titleHi: 'प्रधानमंत्री फसल बीमा योजना (सहकारी खिड़की)',
    ministry: 'Ministry of Agriculture & Cooperation',
    category: 'Credit & Finance',
    targetGroup: ['farmer'],
    subsidyAmount: 'Farmer pays only 1.5% (Rabi) / 2% (Kharif) / 5% (Commercial); Rest shared by Centre & State',
    benefits: [
      'Comprehensive risk insurance covering prevented sowing, mid-season adversity, post-harvest losses, and localized calamities.',
      'Automated claim payout directly to farmer bank account via Aadhaar-linked DBT.',
      'Satellite and remote sensing crop-cutting experiments for fair yield assessment.'
    ],
    eligibilityCriteria: [
      'All farmers growing notified crops in notified areas (both loanee and non-loanee).',
      'Landholding proof (Khatauni/7/12) or certified tenant/sharecropper agreement.'
    ],
    requiredDocs: [
      'Land Record (ROR/7-12/Khasra)',
      'Sowing Certificate / Declaration from Patwari or PACS',
      'Bank Passbook / Aadhaar linked account'
    ],
    status: 'Active / Open',
    deadline: 'Kharif: 31 July | Rabi: 31 December',
    stateApplicability: 'Notified States & Districts'
  }
];

export const MOCK_GRIEVANCES: GrievanceRecord[] = [
  {
    id: 'GRV-2026-9481',
    category: 'Membership Denial',
    complainantName: 'Rameshwar Patel',
    mobile: '9876543210',
    societyName: 'Shrirampur Primary Agricultural Credit Society',
    district: 'Sehore',
    state: 'Madhya Pradesh',
    dateFiled: '2026-08-18',
    status: 'Hearing Scheduled',
    priority: 'Urgent',
    description: 'Applied for regular PACS membership 45 days ago with complete land records. The Society Secretary refuses to issue share certificate stating lack of quota, in violation of Model Bye-Laws Clause 4.',
    slaRemainingDays: 4,
    assignedOfficer: 'S. K. Verma (Deputy Registrar, Co-op)',
    timeline: [
      { stage: 'Grievance Registered Online', date: '18 Aug 2026', remarks: 'Acknowledgement generated. SMS sent to applicant.', completed: true },
      { stage: 'Assigned to Block Cooperative Inspector', date: '20 Aug 2026', remarks: 'Notice issued to PACS Secretary for explanation.', completed: true },
      { stage: 'Secretary Response Received', date: '25 Aug 2026', remarks: 'Explanation deemed unsatisfactory by Inspector.', completed: true },
      { stage: 'Formal Hearing with Deputy Registrar', date: '04 Sep 2026', remarks: 'Scheduled at District Cooperative Office Sehore.', completed: false },
      { stage: 'Final Order & Membership Issuance', date: 'Pending', remarks: 'Expected within statutory 30-day window.', completed: false }
    ]
  },
  {
    id: 'GRV-2026-8812',
    category: 'Dividend Dispute',
    complainantName: 'Sunita Devi',
    mobile: '9812345678',
    societyName: 'Kisan Kranti Multipurpose Society',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    dateFiled: '2026-08-05',
    status: 'Resolved',
    priority: 'Standard',
    description: 'Society declared 9% dividend in AGM for FY 2025-26, but dividend credit of ₹3,420 was withheld for 6 months without explanation.',
    slaRemainingDays: 0,
    assignedOfficer: 'M. P. Mishra (Assistant Registrar)',
    timeline: [
      { stage: 'Grievance Registered', date: '05 Aug 2026', remarks: 'Case ID generated.', completed: true },
      { stage: 'Audit Verification', date: '11 Aug 2026', remarks: 'DCCB Varanasi confirmed society had retained funds.', completed: true },
      { stage: 'Direct Credit Directive', date: '16 Aug 2026', remarks: 'Society directed to disburse with 6% statutory interest.', completed: true },
      { stage: 'Resolved & Closed', date: '22 Aug 2026', remarks: 'Amount ₹3,522 successfully credited to member account.', completed: true }
    ]
  },
  {
    id: 'GRV-2026-7904',
    category: 'Fertilizer Overpricing / Black Marketing',
    complainantName: 'Gurpreet Singh',
    mobile: '9845012345',
    societyName: 'Majha Agricultural Co-op Society',
    district: 'Amritsar',
    state: 'Punjab',
    dateFiled: '2026-08-28',
    status: 'Under Investigation',
    priority: 'Urgent',
    description: 'PACS outlet manager charging ₹320 per bag of Urea against subsidized MRP of ₹266.50 and forcing purchase of unwanted bio-stimulant bottle.',
    slaRemainingDays: 6,
    assignedOfficer: 'Harpreet Kaur (District Agriculture Co-op Officer)',
    timeline: [
      { stage: 'Grievance Logged via SahkarVaani Voice', date: '28 Aug 2026', remarks: 'Voice transcript converted to official grievance.', completed: true },
      { stage: 'Surprise Inspection Dispatched', date: '30 Aug 2026', remarks: 'Physical POS machine inventory reconciliation in progress.', completed: true },
      { stage: 'Show Cause Notice to Manager', date: 'Pending', remarks: 'Awaiting stock audit sheet.', completed: false }
    ]
  }
];

export const PACS_SERVICES: PACSService[] = [
  {
    id: 'pacs-1',
    title: 'Short & Medium Term Crop Loans (KCC)',
    titleHi: 'अल्पकालिक एवं मध्यमकालिक फसल ऋण (KCC)',
    category: 'Agricultural Credit',
    description: 'Interest subvented agricultural credit up to ₹3,00,000 at effective 4% annual interest rate upon timely repayment.',
    descriptionHi: 'समय पर पुनर्भुगतान पर प्रभावी 4% वार्षिक ब्याज दर पर ₹3,00,000 तक ब्याज अनुदानित कृषि ऋण।',
    processingTime: '3-5 Working Days',
    subsidyOrFee: 'Govt 3% prompt repayment incentive',
    requiredDocuments: ['Kisan Credit Card', 'Aadhaar Card', 'Land 7/12 or Khasra', 'Sowing certificate'],
    iconName: 'CreditCard'
  },
  {
    id: 'pacs-2',
    title: 'Subsidized Fertilizers, Seeds & Bio-Nutrients',
    titleHi: 'सब्सिडी वाले उर्वरक, बीज एवं जैविक पोषक तत्व',
    category: 'Fertilizers & Seeds',
    description: 'Certified neem-coated Urea, DAP, MoP, and certified HYV seeds supplied at direct Central Government subsidized MRP through biometric POS.',
    descriptionHi: 'बायोमेट्रिक पीओएस के माध्यम से प्रत्यक्ष केंद्र सरकार की सब्सिडी वाली एमआरपी पर नीम-लेपित यूरिया, डीएपी और प्रमाणित बीज।',
    processingTime: 'Instant / Same Day',
    subsidyOrFee: 'Official MRP only; zero overcharge guarantee',
    requiredDocuments: ['Aadhaar biometric', 'Member Passbook'],
    iconName: 'Sprout'
  },
  {
    id: 'pacs-3',
    title: 'Custom Hiring Centre (Farm Drone & Heavy Machinery)',
    titleHi: 'कस्टम हायरिंग सेंटर (कृषि ड्रोन एवं भारी मशीनरी)',
    category: 'Custom Hiring / Drone',
    description: 'Affordable hourly rental of tractors, rotavators, laser levellers, and DGCA-certified agricultural spray drones for pesticide/nano-urea application.',
    descriptionHi: 'कीटनाशक और नैनो-यूरिया छिड़काव के लिए ट्रैक्टर, लेजर लेवलर और प्रमाणित कृषि ड्रोन का किफायती प्रति घंटे किराया।',
    processingTime: 'Book 24 Hours in advance',
    subsidyOrFee: '50-60% cheaper than private contractor rates',
    requiredDocuments: ['Field Area Details', 'Crop Type'],
    iconName: 'Plane'
  },
  {
    id: 'pacs-4',
    title: 'Common Service Centre (CSC) Digital Services',
    titleHi: 'कॉमन सर्विस सेंटर (CSC) डिजिटल नागरिक सेवाएं',
    category: 'CSC & Digital Services',
    description: 'Over 300 government-to-citizen services including PM-Kisan e-KYC, Aadhaar updates, PAN Card, electricity bill payment, and birth certificates right in the village.',
    descriptionHi: 'गांव में ही पीएम-किसान ई-केवाईसी, आधार अपडेट, पैन कार्ड, बिजली बिल भुगतान सहित 300 से अधिक डिजिटल सेवाएं।',
    processingTime: 'Instant (10-15 Minutes)',
    subsidyOrFee: 'Standard government service charges (₹10 - ₹50)',
    requiredDocuments: ['Aadhaar Card', 'Mobile OTP'],
    iconName: 'Laptop'
  },
  {
    id: 'pacs-5',
    title: 'Pradhan Mantri Jan Aushadhi Generic Medicine Kendra',
    titleHi: 'प्रधानमंत्री जन औषधि जेनेरिक दवा केंद्र',
    category: 'Storage & Warehousing',
    description: 'Quality generic medicines, surgical items, and nutraceuticals at 50% to 90% lesser cost compared to branded market drugs.',
    descriptionHi: 'ब्रांडेड बाजार दवाओं की तुलना में 50% से 90% कम कीमत पर गुणवत्तापूर्ण जेनेरिक दवाएं और सर्जिकल सामान।',
    processingTime: 'Walk-in dispensary',
    subsidyOrFee: '50-90% Discounted MRP',
    requiredDocuments: ['Doctor Prescription (where required)'],
    iconName: 'ShieldCheck'
  },
  {
    id: 'pacs-6',
    title: 'Micro-ATM & AePS Cash Deposit/Withdrawal',
    titleHi: 'माइक्रो-एटीएम एवं आधार सक्षम भुगतान (AePS) नकद निकासी',
    category: 'Insurance & Micro-ATM',
    description: 'Doorstep cash withdrawal and direct DBT receipt using Aadhaar fingerprint or Rupay debit card without travelling to city bank branches.',
    descriptionHi: 'शहर के बैंक शाखा जाए बिना आधार फिंगरप्रिंट या रुपे कार्ड का उपयोग करके गांव में ही नकद निकासी और डीबीटी।',
    processingTime: 'Instant (2 Minutes)',
    subsidyOrFee: 'Zero transaction fee for farmers',
    requiredDocuments: ['Aadhaar No + Biometric Fingerprint'],
    iconName: 'Coins'
  },
  {
    id: 'pacs-7',
    title: 'Decentralized Cold Storage & Grain Godown (e-NWR)',
    titleHi: 'विकेंद्रीकृत कोल्ड स्टोरेज एवं अनाज गोदाम',
    category: 'Storage & Warehousing',
    description: 'Scientific storage with pest protection. Generates electronic warehouse receipts (e-NWR) eligible for 70% pledge loan at 7% interest.',
    descriptionHi: 'कीट सुरक्षा के साथ वैज्ञानिक भंडारण। 7% ब्याज पर 70% गिरवी ऋण के लिए पात्र इलेक्ट्रॉनिक रसीद (e-NWR) उत्पन्न करता है।',
    processingTime: 'Same Day Intake & Weighment',
    subsidyOrFee: 'Nominal monthly bag rate (₹5/bag/month)',
    requiredDocuments: ['Moisture Test Certificate', 'Member ID'],
    iconName: 'Warehouse'
  },
  {
    id: 'pacs-8',
    title: 'Bulk Milk Collection & Dairy Testing Centre',
    titleHi: 'थोक दूध संग्रह एवं डेयरी परीक्षण केंद्र',
    category: 'Dairy & Fisheries',
    description: 'Automated computerized milk fat/SNF testing with instant digital slip generation and direct weekly payment credit to milk producer accounts.',
    descriptionHi: 'स्वचालित दूध फैट/एसएनएफ परीक्षण, तत्काल पर्ची और दुग्ध उत्पादक बैंक खातों में प्रत्यक्ष साप्ताहिक भुगतान।',
    processingTime: 'Daily Morning & Evening',
    subsidyOrFee: 'Transparent fat-based pricing linked to State Co-op Dairy Federation',
    requiredDocuments: ['Cattle Tag No', 'Member ID'],
    iconName: 'Milk'
  }
];

export const INITIAL_AI_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'assistant',
    text: 'नमस्ते! मैं आपका सहकार मित्र (SahkarMitra) हूँ — सहकारिता मंत्रालय द्वारा संचालित आपका कानूनी व सहकारी एआई सहायक।\n\nआप मुझसे सहकारी नियमों, पैक्स (PACS) सदस्यता, लाभांश विवाद, पीएम फसल बीमा या सरकारी योजनाओं के बारे में किसी भी भारतीय भाषा में पूछ सकते हैं। मैं आपकी किस प्रकार सहायता करूँ?',
    language: 'hi',
    timestamp: '10:00 AM',
    suggestedActions: [
      'सहकारी समिति में सदस्य के अधिकार क्या हैं?',
      'पैक्स में सदस्यता से मना करने पर शिकायत कैसे करें?',
      'PMFBY फसल बीमा की गणना कैसे करें?',
      'मॉडल पैक्स उप-नियम 2023 की मुख्य बातें बताएं'
    ]
  }
];

export const SAMPLE_AI_RESPONSES: Record<string, { text: string; citations: { act: string; section: string; clause: string; title: string; }[]; confidence: number; suggestedActions: string[] }> = {
  rights: {
    text: 'सहकारी समिति के सक्रिय सदस्य के रूप में आपको भारतीय कानून के तहत निम्नलिखित 5 प्रमुख वैधानिक अधिकार प्राप्त हैं:\n\n1. **लोकतांत्रिक मतदान का अधिकार (One Member, One Vote)**: शेयर पूंजी के आकार की परवाह किए बिना प्रत्येक सदस्य का 1 वोट होता है (धारा 29).\n2. **वार्षिक आम बैठक (AGM) व ऑडिट निरीक्षण**: आपको समिति की वार्षिक बैलेंस शीट, लाभ-हानि खाता और लेखापरीक्षा रिपोर्ट का निरीक्षण करने का पूर्ण अधिकार है.\n3. **लाभांश व बोनस का अधिकार**: समिति के शुद्ध लाभ में से घोषित लाभांश प्राप्त करने का अधिकार.\n4. **चुनाव लड़ने व निदेशक चुनने का अधिकार**: निर्धारित पात्रता पूरी करने पर बोर्ड चुनाव में उम्मीदवार बनने का अधिकार.\n5. **सूचना व शिकायत निवारण का अधिकार**: किसी भी अनियमितता पर सहकारी लोकपाल अथवा सहायक निबंधक के समक्ष 30 दिनों में सुनवाई का अधिकार.',
    citations: [
      { act: 'Multi-State Cooperative Societies Act', section: 'Section 29', clause: 'Sub-clause (1)', title: 'Voting Rights of Members' },
      { act: 'Model Bye-Laws for PACS, 2023', section: 'Clause 18', clause: 'Rights & Duties', title: 'Member Governance Standards' }
    ],
    confidence: 98,
    suggestedActions: ['शिकायत दर्ज करने की प्रक्रिया जानें', 'निर्वाचन नियम 2023 देखें', 'निबंधक से संपर्क करें']
  },
  complaint: {
    text: 'यदि कोई पैक्स (PACS) या सहकारी समिति आपको मनमाने ढंग से सदस्यता देने से मना करती है, उर्वरक में अधिक पैसे वसूलती है या लाभांश नहीं देती, तो आप इन 3 स्तरों पर कार्यवाही कर सकते हैं:\n\n1. **प्रथम स्तर (आंतरिक शिकायत)**: समिति के सचिव/अध्यक्ष को लिखित आवेदन दें. उन्हें 15 दिनों में उत्तर देना अनिवार्य है.\n2. **द्वितीय स्तर (सहकार सेतु डिजिटल शिकायत)**: हमारे "शिकायत निवारण" पोर्टल पर ऑनलाइन शिकायत दर्ज करें. आपको एक विशिष्ट ट्रैकिंग नंबर (GRV-ID) मिलेगा, जिसकी जिला सहायक निबंधक द्वारा 30 दिनों में अनिवार्य जांच होगी.\n3. **तृतीय स्तर (सहकारी लोकपाल / निबंधक)**: मल्टी-स्टेट सहकारी अधिनियम की धारा 84 के तहत लोकपाल को सीधे याचिका प्रस्तुत की जा सकती है.',
    citations: [
      { act: 'MSCS (Amendment) Act 2023', section: 'Section 84 & 85', clause: 'Ombudsman Redressal', title: 'Statutory Grievance Mechanism' },
      { act: 'Model PACS Bye-Laws', section: 'Clause 4(c)', clause: 'Open Membership', title: 'Deemed Membership Provisions' }
    ],
    confidence: 96,
    suggestedActions: ['अभी ऑनलाइन शिकायत दर्ज करें', 'शिकायत की स्थिति जांचें', 'सहायक निबंधक से बात करें']
  },
  pmfby: {
    text: 'प्रधानमंत्री फसल बीमा योजना (PMFBY) के तहत किसानों के लिए प्रीमियम दरें बेहद रियायती और निश्चित हैं:\n\n• **खरीफ फसलें (उदा. धान, सोयाबीन, कपास)**: बीमित राशि का केवल **2.0%** किसान देता है.\n• **रबी फसलें (उदा. गेहूं, सरसों, चना)**: बीमित राशि का केवल **1.5%** किसान देता है.\n• **व्यावसायिक/बागवानी फसलें (उदा. गन्ना, फल)**: बीमित राशि का केवल **5.0%** किसान देता है.\n\nशेष प्रीमियम राशि का 50% केंद्र सरकार और 50% राज्य सरकार द्वारा वहन किया जाता है. प्राकृतिक आपदा या बेमौसम बारिश से नुकसान होने पर 72 घंटे के भीतर सूचना देना अनिवार्य है.',
    citations: [
      { act: 'PMFBY Operational Guidelines 2024', section: 'Chapter 4', clause: 'Premium Subsidy Matrix', title: 'Farmer Share Regulations' },
      { act: 'National Crop Insurance Portal Directives', section: 'Rule 12', clause: '72-hour Intimation Protocol', title: 'Claim Trigger Protocol' }
    ],
    confidence: 99,
    suggestedActions: ['प्रीमियम कैलकुलेटर खोलें', 'फसल दावा (Claim) की स्थिति जांचें', 'मौसम सलाह देखें']
  },
  election: {
    text: 'सहकारी समितियों के लिए 2023 के संशोधित निर्वाचन नियम अत्यंत पारदर्शी हैं:\n\n1. **सहकारी निर्वाचन प्राधिकरण (CEA)**: चुनाव अब समिति के अपने अधिकारियों द्वारा नहीं, बल्कि एक स्वतंत्र प्राधिकरण द्वारा निष्पक्ष रूप से कराए जाते हैं.\n2. **अनिवार्य आरक्षण**: प्रबंध समिति में कम से कम **2 सीटें महिलाओं** के लिए और **1 सीट अनुसूचित जाति / जनजाति** के लिए आरक्षित है.\n3. **मतदाता सूची प्रकाशन**: चुनाव से न्यूनतम 30 दिन पहले मतदाता सूची सार्वजनिक करना अनिवार्य है.\n4. **अयोग्यता नियम**: लगातार 2 वर्ष तक वार्षिक आम सभा (AGM) न कराने या ऑडिट न कराने वाले निदेशकों को पद से हटा दिया जाता है.',
    citations: [
      { act: 'MSCS (Amendment) Act 2023', section: 'Section 45', clause: 'Cooperative Election Authority', title: 'Mandatory Electoral Framework' },
      { act: 'Conduct of Election Rules', section: 'Rule 8', clause: 'Reservation & Voter Roll', title: 'Democratic Quota Enforcement' }
    ],
    confidence: 97,
    suggestedActions: ['चुनाव नियमावली डाउनलोड करें', 'राज्यवार तुलना देखें', 'कानूनी सलाह लें']
  }
};

export const RECENT_CIRCULARS = [
  {
    id: 'circ-1',
    refNo: 'MOC/PACS/2026/08/94',
    title: 'Advisory on Zero Tolerance for Fertilizer Black Marketing in PACS Outlets',
    titleHi: 'पैक्स बिक्री केंद्रों में उर्वरक कालाबाजारी पर जीरो टॉलरेंस परामर्श',
    date: '28 Aug 2026',
    category: 'Strict Enforcement',
    fileSize: '420 KB PDF'
  },
  {
    id: 'circ-2',
    refNo: 'MOC/STORAGE/2026/07/112',
    title: 'Allocation of 10,000 New Decentralized Grain Godowns under PACS Convergence Scheme',
    titleHi: 'पैक्स अभिसरण योजना के तहत 10,000 नए विकेंद्रीकृत अनाज गोदामों का आवंटन',
    date: '15 Aug 2026',
    category: 'Infrastructure',
    fileSize: '1.2 MB PDF'
  },
  {
    id: 'circ-3',
    refNo: 'MOC/ELEC/2026/07/04',
    title: 'Standard Operating Procedure for 2026 Cooperative Board Elections with CEA Oversight',
    titleHi: 'सीईए निगरानी के साथ 2026 सहकारी बोर्ड चुनावों के लिए मानक संचालन प्रक्रिया',
    date: '22 Jul 2026',
    category: 'Elections',
    fileSize: '890 KB PDF'
  }
];

export const ADMIN_METRICS = {
  totalPACSComputerized: 68412,
  activeGrievances: 148,
  cropClaimsSettledAmountCr: 12480,
  grainStorageCapacityMT: 4500000,
  totalPACSCount: 102000,
  resolvedGrievanceRatePercent: 94.2
};

