export * from '../locales';
