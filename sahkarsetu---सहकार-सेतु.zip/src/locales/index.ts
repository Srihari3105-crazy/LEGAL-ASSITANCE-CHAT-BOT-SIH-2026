import { LanguageCode, LanguageOption } from '../types';
import { en } from './en';
import { hi } from './hi';
import { ta } from './ta';
import { te } from './te';
import { bn } from './bn';
import { mr } from './mr';
import { gu } from './gu';
import { kn } from './kn';
import { ml } from './ml';
import { pa } from './pa';
import { or } from './or';
import { ur } from './ur';

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English', script: 'Latin', bcp47: 'en-IN', dir: 'ltr' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', script: 'Devanagari', bcp47: 'hi-IN', dir: 'ltr' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', script: 'Tamil', bcp47: 'ta-IN', dir: 'ltr' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', script: 'Telugu', bcp47: 'te-IN', dir: 'ltr' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', script: 'Bengali', bcp47: 'bn-IN', dir: 'ltr' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', script: 'Devanagari', bcp47: 'mr-IN', dir: 'ltr' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', script: 'Gujarati', bcp47: 'gu-IN', dir: 'ltr' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', script: 'Kannada', bcp47: 'kn-IN', dir: 'ltr' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', script: 'Malayalam', bcp47: 'ml-IN', dir: 'ltr' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', script: 'Gurmukhi', bcp47: 'pa-IN', dir: 'ltr' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', script: 'Odia', bcp47: 'or-IN', dir: 'ltr' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', script: 'Arabic/Perso-Arabic', bcp47: 'ur-IN', dir: 'rtl' },
];

export const INDIAN_LANGUAGES = SUPPORTED_LANGUAGES;

export const UI_TRANSLATIONS: Record<LanguageCode, typeof en> = {
  en,
  hi,
  ta,
  te,
  bn,
  mr,
  gu,
  kn,
  ml,
  pa,
  or,
  ur,
};

export type TranslationKey = keyof typeof en;

export function getTranslation(lang: LanguageCode = 'en') {
  return UI_TRANSLATIONS[lang] || UI_TRANSLATIONS.en;
}
