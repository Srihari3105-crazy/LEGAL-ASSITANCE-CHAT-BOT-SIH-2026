/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PageId, LanguageCode, UserRole } from './types';
import { UI_TRANSLATIONS } from './data/translations';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { LandingPage } from './components/LandingPage';
import { CitizenDashboard } from './components/CitizenDashboard';
import { SahkarMitraChat } from './components/SahkarMitraChat';
import { LawsPage } from './components/LawsPage';
import { SchemesPage } from './components/SchemesPage';
import { PMFBYPage } from './components/PMFBYPage';
import { GrievancePortal } from './components/GrievancePortal';
import { FinancialLiteracyPage } from './components/FinancialLiteracyPage';
import { PACSServicesPage } from './components/PACSServicesPage';
import { SahkarVaaniVoice } from './components/SahkarVaaniVoice';
import { AdminDashboard } from './components/AdminDashboard';
import {
  MessageSquare,
  Radio,
  Sparkles,
  Volume2,
  Maximize2,
  Minimize2,
  Layers,
  HeartHandshake,
  CheckCircle2
} from 'lucide-react';

const VALID_LANGUAGES: LanguageCode[] = [
  'en', 'hi', 'ta', 'te', 'bn', 'mr', 'gu', 'kn', 'ml', 'pa', 'or', 'ur'
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('landing');
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>(() => {
    try {
      const saved = localStorage.getItem('sahkarsetu_language') as LanguageCode;
      if (saved && VALID_LANGUAGES.includes(saved)) {
        return saved;
      }
    } catch (e) {
      // ignore localStorage errors
    }
    return 'en';
  });
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [isHighContrast, setIsHighContrast] = useState<boolean>(false);
  const [isScreenReaderActive, setIsScreenReaderActive] = useState<boolean>(false);
  const [isKioskMode, setIsKioskMode] = useState<boolean>(false);
  const [userRole, setUserRole] = useState<UserRole>('farmer');
  const [aiInitialQuery, setAiInitialQuery] = useState<string | undefined>(undefined);
  const [showToast, setShowToast] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('');

  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  // Persist language and update HTML document attributes
  const handleLanguageChange = (newLang: LanguageCode) => {
    if (newLang === currentLanguage) return;
    setCurrentLanguage(newLang);
    try {
      localStorage.setItem('sahkarsetu_language', newLang);
    } catch (e) {
      // ignore
    }
    const newT = UI_TRANSLATIONS[newLang] || UI_TRANSLATIONS.en;
    setToastMessage(newT.langChangedToast || 'Language updated');
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  useEffect(() => {
    document.documentElement.lang = currentLanguage;
    document.documentElement.dir = currentLanguage === 'ur' ? 'rtl' : 'ltr';
  }, [currentLanguage]);

  // Trigger SahkarMitra chat with prefilled query
  const handleAskAI = (query: string) => {
    setAiInitialQuery(query);
    setCurrentPage('chat');
  };

  // Font size multiplier class
  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large': return 'text-[17px]';
      case 'xlarge': return 'text-[19px]';
      default: return 'text-[15px]';
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors ${
        isHighContrast
          ? 'bg-black text-amber-300'
          : 'bg-[#FDFBF7] text-[#333333]'
      } ${getFontSizeClass()}`}
    >
      {/* Toast Notification for Language Switch */}
      {showToast && (
        <div className="fixed top-16 right-4 sm:right-8 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-emerald-900 text-white shadow-xl border border-emerald-700 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Top Global Header with Indian Emblem, Multilingual Switcher & Accessibility */}
      <Header
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        currentLanguage={currentLanguage}
        setCurrentLanguage={handleLanguageChange}
        kioskMode={isKioskMode}
        setKioskMode={setIsKioskMode}
        fontSize={fontSize}
        setFontSize={setFontSize}
        isHighContrast={isHighContrast}
        setIsHighContrast={setIsHighContrast}
        mobileMenuOpen={false}
        setMobileMenuOpen={() => {}}
      />

      {/* Main Layout Area */}
      <div className="flex-1 flex w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Desktop Sidebar (Hidden on landing page & kiosk mode if preferred) */}
        {!isKioskMode && currentPage !== 'landing' && (
          <aside className="hidden lg:block w-64 shrink-0">
            <Sidebar
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              currentLanguage={currentLanguage}
            />
          </aside>
        )}

        {/* Dynamic Main View */}
        <main className="flex-1 min-w-0 pb-20 lg:pb-8">
          {currentPage === 'landing' && (
            <LandingPage
              onNavigate={setCurrentPage}
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
              onOpenKioskMode={() => setIsKioskMode(true)}
            />
          )}

          {currentPage === 'dashboard' && (
            <CitizenDashboard
              onNavigate={setCurrentPage}
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'chat' && (
            <SahkarMitraChat
              currentLanguage={currentLanguage}
              setCurrentLanguage={handleLanguageChange}
              onNavigateToGrievance={() => setCurrentPage('grievance')}
              onNavigateToPmfby={() => setCurrentPage('pmfby')}
              initialQuery={aiInitialQuery}
            />
          )}

          {currentPage === 'voice' && (
            <SahkarVaaniVoice
              currentLanguage={currentLanguage}
              onLanguageChange={handleLanguageChange}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'laws' && (
            <LawsPage
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'schemes' && (
            <SchemesPage
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'pmfby' && (
            <PMFBYPage
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'grievance' && (
            <GrievancePortal
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'financial' && (
            <FinancialLiteracyPage
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'pacs' && (
            <PACSServicesPage
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}

          {currentPage === 'admin' && (
            <AdminDashboard
              currentLanguage={currentLanguage}
              onAskAI={handleAskAI}
            />
          )}
        </main>
      </div>

      {/* Floating Action Button (FAB) for Quick AI Assistant & Voice */}
      {currentPage !== 'chat' && currentPage !== 'voice' && (
        <div className="fixed bottom-20 lg:bottom-6 right-5 z-40 flex flex-col gap-2.5">
          <button
            onClick={() => setCurrentPage('voice')}
            title={t.voiceVaani}
            className="w-12 h-12 rounded-full bg-[#FF9933] hover:bg-[#e68a2e] hover:scale-105 text-white font-bold shadow-md flex items-center justify-center transition-all border-2 border-white group cursor-pointer"
          >
            <Radio className="w-5 h-5 group-hover:animate-pulse" />
          </button>

          <button
            onClick={() => {
              setAiInitialQuery(undefined);
              setCurrentPage('chat');
            }}
            title={t.askMitra}
            className="px-5 py-3 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] hover:scale-105 text-white font-bold text-xs shadow-md flex items-center gap-2 transition-all border-2 border-white cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#FF9933]" />
            <span className="hidden sm:inline">{t.askMitra}</span>
          </button>
        </div>
      )}

      {/* Mobile Bottom Navigation */}
      <BottomNav
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        currentLanguage={currentLanguage}
        onOpenMoreMenu={() => setCurrentPage('dashboard')}
      />

      {/* Official Footer */}
      <footer className="bg-white border-t border-[#E8E1D5] mt-auto py-6 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#075B46]"></span>
            <span className="font-extrabold text-[#333333]">{t.appName}</span>
            <span>• SIH 2026</span>
          </div>

          <p className="text-[11px] text-gray-500">
            {t.footerCopyright || t.ministryBadge}
          </p>

          <div className="flex items-center gap-3 text-[11px] text-[#555555] font-semibold">
            <button onClick={() => setCurrentPage('laws')} className="hover:text-[#075B46] cursor-pointer">
              {t.navLaws}
            </button>
            <span>•</span>
            <button onClick={() => setCurrentPage('schemes')} className="hover:text-[#075B46] cursor-pointer">
              {t.navSchemes}
            </button>
            <span>•</span>
            <button onClick={() => setCurrentPage('grievance')} className="hover:text-[#075B46] cursor-pointer">
              {t.navGrievance}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
