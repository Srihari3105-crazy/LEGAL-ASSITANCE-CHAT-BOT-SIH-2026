import JSZip from 'jszip';

export async function downloadProjectZip() {
  const zip = new JSZip();

  // Load all raw source files in project
  const meta = import.meta as unknown as { glob: (pattern: string | string[], options?: object) => Record<string, string> };
  
  const rootFiles = meta.glob(['/index.html', '/package.json', '/tsconfig.json', '/vite.config.ts', '/.env.example', '/metadata.json'], {
    query: '?raw',
    eager: true,
    import: 'default'
  });

  const srcFiles = meta.glob(['/src/**/*.{ts,tsx,css,json,js}'], {
    query: '?raw',
    eager: true,
    import: 'default'
  });

  // Add root files
  for (const [path, content] of Object.entries(rootFiles)) {
    const cleanPath = path.replace(/^\//, '');
    zip.file(cleanPath, content);
  }

  // Add src files
  for (const [path, content] of Object.entries(srcFiles)) {
    const cleanPath = path.replace(/^\//, '');
    zip.file(cleanPath, content);
  }

  // Generate README.md with setup instructions
  zip.file('README.md', `# SahkarSetu (सहकारसेतु) - AI-Powered Citizen Legal & Information Portal

## Tech Stack
- React 19 + TypeScript + Vite + Tailwind CSS
- Gemini AI / Google GenAI Integration
- Multi-Language Localization (12 Indian Languages)

## Setup & Running Locally
1. Clone or extract this repository
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`
4. Build for production:
   \`\`\`bash
   npm run build
   \`\`\`
`);

  // Generate blob and trigger browser download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `sahkarsetu-portal-source-${new Date().toISOString().slice(0, 10)}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
