import React, { useState } from 'react';
import { LanguageCode } from '../types';
import { INDIAN_LANGUAGES, UI_TRANSLATIONS } from '../locales';
import {
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  Radio,
  Square
} from 'lucide-react';

interface SahkarVaaniVoiceProps {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onAskAI: (query: string) => void;
}

export const SahkarVaaniVoice: React.FC<SahkarVaaniVoiceProps> = ({
  currentLanguage,
  onLanguageChange,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const isHi = currentLanguage === 'hi';

  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [aiVoiceResponse, setAiVoiceResponse] = useState<string>(
    isHi
      ? 'नमस्ते किसान भाई! मैं सहकार वाणी हूँ। आप अपनी भाषा में बोलकर सहकारी नियम, फसल बीमा या खाद की उपलब्धता के बारे में पूछ सकते हैं।'
      : 'Hello! I am SahkarVaani Voice Assistant. Speak in your language to ask about cooperative laws, crop insurance, fertilizer stock, or KCC loans.'
  );

  const QUICK_VOICE_PROMPTS = [
    {
      hi: 'मेरी पैक्स में DAP खाद का नया स्टॉक कब आएगा?',
      en: 'When will DAP fertilizer arrive in my PACS?',
      topic: isHi ? 'खाद स्टॉक' : 'Fertilizer Stock'
    },
    {
      hi: 'फसल नुकसान होने पर 72 घंटे में बीमा दावा कैसे दर्ज करें?',
      en: 'How to report crop loss claim within 72 hours in PMFBY?',
      topic: isHi ? 'फसल बीमा' : 'PMFBY Crop Loss'
    },
    {
      hi: 'क्या सहकारी समिति संचालक मंडल में महिलाओं हेतु सीट आरक्षित है?',
      en: 'Is there reservation for women directors on PACS board?',
      topic: isHi ? 'महिला आरक्षण' : 'Women Reservation'
    },
    {
      hi: 'किसान क्रेडिट कार्ड पर 3% ब्याज अनुदान कैसे मिलता है?',
      en: 'How to get 3% interest subvention on KCC loan?',
      topic: isHi ? 'केसीसी 4% ऋण' : 'KCC 4% Loan'
    }
  ];

  const handleToggleMic = () => {
    if (isListening) {
      setIsListening(false);
    } else {
      setIsListening(true);
      setTranscript(isHi ? 'सुन रहा हूँ... बोलिए' : 'Listening... please speak');

      // Simulate recognition
      setTimeout(() => {
        setIsListening(false);
        const recognizedText = isHi
          ? 'मेरी पैक्स में DAP खाद का नया स्टॉक कब आएगा?'
          : 'When will DAP fertilizer arrive in my PACS?';
        setTranscript(recognizedText);
        speakResponse(
          isHi
            ? 'आपकी सीहोर श्रीरामुपर पैक्स में कल 450 बोरी DAP खाद की नई खेप आ रही है। प्रति सदस्य अधिकतम 5 बोरी का कोटा निर्धारित है।'
            : 'Your local PACS will receive a fresh stock of 450 bags of DAP fertilizer tomorrow. A quota of up to 5 bags per member applies.'
        );
      }, 2600);
    }
  };

  const speakResponse = (text: string) => {
    setAiVoiceResponse(text);
    setIsSpeaking(true);

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = isHi ? 'hi-IN' : 'en-IN';
      utterance.rate = 0.95;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setTimeout(() => setIsSpeaking(false), 4000);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  const handleSelectPrompt = (prompt: { hi: string; en: string }) => {
    const promptText = isHi ? prompt.hi : prompt.en;
    setTranscript(promptText);
    if (prompt.en.includes('72 hours') || prompt.hi.includes('72 घंटे')) {
      speakResponse(
        isHi
          ? 'आपदा आने के 72 घंटे के भीतर टोल-फ्री 14447 पर कॉल करें या ऐप पर खेत का फोटो अपलोड करें। 10 दिनों में संयुक्त पंचनामा बनेगा और 30 दिनों में DBT बैंक ट्रांसफर होगा।'
          : 'Within 72 hours of localized calamity, call toll-free 14447 or upload geo-tagged photo in the app. Verification occurs in 10 days and claims are disbursed within 30 days.'
      );
    } else if (prompt.en.includes('women') || prompt.hi.includes('महिलाओं')) {
      speakResponse(
        isHi
          ? 'हाँ! मॉडल पैक्स 2023 उप-नियमों एवं MSCS अधिनियम के तहत संचालक मंडल में कम से कम 2 महिला निदेशकों का आरक्षण अनिवार्य है।'
          : 'Yes! Under Model PACS Bye-laws 2023 and MSCS Act, at least 2 seats on the Board of Directors are statutorily reserved for women.'
      );
    } else if (prompt.en.includes('subvention') || prompt.hi.includes('3% ब्याज')) {
      speakResponse(
        isHi
          ? 'केसीसी पर आधार ब्याज दर 7% है। यदि आप 12 माह के भीतर पूरा ऋण चुकाते हैं, तो केंद्र सरकार 3% ब्याज छूट देती है, जिससे शुद्ध ब्याज केवल 4% लगता है।'
          : 'Base interest on KCC is 7%. Prompt repayment within 12 months earns 3% central interest subvention, effectively reducing the net rate to only 4%.'
      );
    } else {
      speakResponse(
        isHi
          ? 'आपकी पैक्स में कल 450 बोरी DAP खाद उपलब्ध होगी। कृपया आधार कार्ड एवं केसीसी पासबुक साथ लाएं।'
          : '450 bags of DAP fertilizer will be available at your PACS tomorrow. Please bring your Aadhaar and KCC passbook.'
      );
    }
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
              <Radio className="w-3.5 h-3.5" />
              <span>{t.voiceAssistant}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {t.voiceTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              {t.voiceSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
              className="p-2.5 rounded-xl border border-slate-200 bg-[#FAF8F5] text-xs font-bold"
            >
              {INDIAN_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.name})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Big Voice Hero Card */}
      <section className="bg-gradient-to-br from-[#075B46] via-[#0B5D4B] to-[#043E30] text-white rounded-[32px] p-8 sm:p-12 border border-emerald-800/40 shadow-xl text-center space-y-8 max-w-3xl mx-auto relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-400/15 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>

        <div className="relative z-10 space-y-2">
          <span className="text-xs font-bold text-amber-200 uppercase tracking-wider">
            {isListening ? `🎤 ${t.listening}` : isSpeaking ? `🔊 ${t.voiceAssistant}` : t.tapToSpeak}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            {transcript || (isHi ? '“माइक बटन दबाकर अपना सवाल पूछें”' : '“Tap microphone and ask your question”')}
          </h2>
        </div>

        {/* Pulsing Mic Interactive Button */}
        <div className="flex items-center justify-center relative py-4 z-10">
          {/* Wave Ripple Animation */}
          {isListening && (
            <div className="absolute w-44 h-44 rounded-full bg-rose-400/30 animate-ping"></div>
          )}
          {isSpeaking && (
            <div className="absolute w-44 h-44 rounded-full bg-emerald-400/30 animate-pulse"></div>
          )}

          <button
            onClick={handleToggleMic}
            className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full flex flex-col items-center justify-center text-white shadow-2xl transition-all relative z-10 cursor-pointer ${
              isListening
                ? 'bg-rose-600 scale-105 shadow-rose-500/50 ring-8 ring-rose-300/40'
                : isSpeaking
                ? 'bg-white text-[#075B46] scale-105 shadow-emerald-950/50 ring-8 ring-emerald-300/40'
                : 'bg-white text-[#075B46] hover:scale-105 ring-8 ring-white/20 hover:bg-emerald-50'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="w-10 h-10 animate-pulse text-white" />
                <span className="text-[10px] font-bold mt-1 text-white">{t.stopListening}</span>
              </>
            ) : (
              <>
                <Mic className="w-10 h-10 text-[#075B46]" />
                <span className="text-[10px] font-bold mt-1 text-[#075B46]">{t.tapToSpeak}</span>
              </>
            )}
          </button>
        </div>

        {/* Live Visual Waveform */}
        <div className="flex items-center justify-center gap-1.5 h-10 relative z-10">
          {[20, 45, 80, 60, 95, 40, 70, 90, 30, 85, 50, 75, 35, 65, 25].map((height, i) => (
            <div
              key={i}
              className={`w-1.5 rounded-full transition-all duration-150 ${
                isListening
                  ? 'bg-rose-400 animate-bounce'
                  : isSpeaking
                  ? 'bg-amber-300 animate-pulse'
                  : 'bg-white/30'
              }`}
              style={{
                height: isListening || isSpeaking ? `${Math.max(12, (height * (i % 3 + 1)) % 38)}px` : '8px'
              }}
            ></div>
          ))}
        </div>

        {/* AI Spoken Response Display */}
        <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-md text-left space-y-3 relative z-10 text-[#333333]">
          <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-2">
            <span className="text-xs font-bold text-[#075B46] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#FF9933]" />
              <span>{t.voiceAssistant}</span>
            </span>
            <div className="flex items-center gap-2">
              {isSpeaking ? (
                <button
                  onClick={stopSpeaking}
                  className="px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 text-[11px] font-bold border border-rose-200 flex items-center gap-1 cursor-pointer"
                >
                  <Square className="w-3 h-3 fill-rose-700" />
                  <span>{t.stopAudio}</span>
                </button>
              ) : (
                <button
                  onClick={() => speakResponse(aiVoiceResponse)}
                  className="px-2.5 py-1 rounded-full bg-emerald-50 text-[#075B46] text-[11px] font-bold border border-emerald-200 flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-3 h-3" />
                  <span>{t.listenAudio}</span>
                </button>
              )}
            </div>
          </div>

          <p className="text-sm font-medium text-[#333333] leading-relaxed">
            {aiVoiceResponse}
          </p>
        </div>
      </section>

      {/* One-Tap Voice Prompts */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <div className="space-y-1">
          <h3 className="text-base font-bold text-slate-900">
            {t.suggestedQuestions}
          </h3>
          <p className="text-xs text-slate-500">
            {isHi ? 'किसी भी प्रश्न पर क्लिक करके तुरंत उत्तर सुनें।' : 'Click any question below to hear the voice response.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {QUICK_VOICE_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSelectPrompt(p)}
              className="p-4 rounded-2xl bg-[#FAF8F5] hover:bg-emerald-50/60 border border-amber-100 hover:border-emerald-300 text-left transition-all flex items-center justify-between gap-3 group"
            >
              <div className="space-y-1">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600">
                  {p.topic}
                </span>
                <p className="text-xs font-bold text-slate-900 group-hover:text-[#138808]">
                  "{isHi ? p.hi : p.en}"
                </p>
              </div>

              <div className="w-8 h-8 rounded-full bg-white border border-slate-200 group-hover:bg-[#138808] group-hover:text-white flex items-center justify-center text-slate-600 transition-colors shrink-0">
                <Volume2 className="w-4 h-4" />
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
