import React, { useState } from 'react';
import { PageId, LanguageCode, PACSService } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { PACS_SERVICES } from '../data/mockData';
import {
  Store,
  CreditCard,
  Sprout,
  Plane,
  Laptop,
  ShieldCheck,
  Coins,
  Warehouse,
  Milk,
  CheckCircle2,
  Clock,
  FileText,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Building,
  Info
} from 'lucide-react';

interface PACSServicesPageProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const PACSServicesPage: React.FC<PACSServicesPageProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const isEn = currentLanguage === 'en';

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedService, setSelectedService] = useState<PACSService | null>(null);
  const [selectedLinkTier, setSelectedLinkTier] = useState<number | null>(null);

  const CATEGORIES = [
    'All',
    'Agricultural Credit',
    'Fertilizers & Seeds',
    'Storage & Warehousing',
    'Dairy & Fisheries',
    'CSC & Digital Services',
    'Insurance & Micro-ATM',
    'Custom Hiring / Drone'
  ];

  const filteredServices = PACS_SERVICES.filter(
    (s) => selectedCategory === 'All' || s.category === selectedCategory
  );

  const getIcon = (name: string) => {
    switch (name) {
      case 'CreditCard': return <CreditCard className="w-5 h-5" />;
      case 'Sprout': return <Sprout className="w-5 h-5" />;
      case 'Plane': return <Plane className="w-5 h-5" />;
      case 'Laptop': return <Laptop className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      case 'Coins': return <Coins className="w-5 h-5" />;
      case 'Warehouse': return <Warehouse className="w-5 h-5" />;
      case 'Milk': return <Milk className="w-5 h-5" />;
      default: return <Store className="w-5 h-5" />;
    }
  };

  const CREDIT_LINK_TIERS = [
    {
      level: 1,
      name: isEn ? 'NABARD' : 'NABARD (नाबार्ड)',
      role: isEn ? 'Apex Development Bank of India' : 'Apex Development Bank of India',
      rate: '3.50% Refinance Rate',
      desc: 'Provides low-cost concessional refinance fund under Short Term Cooperative Rural Credit (STCRC).'
    },
    {
      level: 2,
      name: isEn ? 'State Co-op Bank (StCB)' : 'State Co-op Bank (राज्य सहकारी बैंक)',
      role: 'State Apex Bank',
      rate: '4.25% Lending Rate',
      desc: 'Balances statewide cooperative liquidity and disburses NABARD refinance to district central banks.'
    },
    {
      level: 3,
      name: isEn ? 'DCCB' : 'DCCB (जिला सहकारी बैंक)',
      role: 'District Central Co-op Bank',
      rate: '5.50% Lending Rate',
      desc: 'Supervises branch networks in each district and extends credit lines to affiliated PACS.'
    },
    {
      level: 4,
      name: isEn ? 'PACS' : 'PACS (पैक्स समिति)',
      role: 'Village Cooperative Entity',
      rate: '7.00% Standard Rate',
      desc: 'Delivers fertilizer, seeds, and KCC credit directly at the farmer door in the village.'
    },
    {
      level: 5,
      name: isEn ? 'Member Farmer' : 'Member Farmer (किसान)',
      role: 'Active Beneficiary Member',
      rate: '4.00% Net Interest Rate',
      desc: 'Farmer receives 3% GOI Prompt Repayment Subvention upon clearing loan within 12 months!'
    }
  ];

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <Store className="w-3.5 h-3.5" />
              <span>{t.navPACS}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featurePACSTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featurePACSDesc}
            </p>
          </div>

          <button
            onClick={() => onAskAI('What services are available at village PACS under Model Bye-laws 2023?')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs shrink-0 shadow-xs cursor-pointer transition-colors"
          >
            <Sparkles className="w-4 h-4 text-[#FF9933]" />
            <span>{t.askMitra}</span>
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#075B46] text-white shadow-2xs'
                  : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* PACS Transformation Progress Tracker */}
      <section className="bg-[#075B46] text-white rounded-3xl p-6 sm:p-8 shadow-sm space-y-5 border border-[#0B5D4B]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <span className="text-xs font-bold text-[#FF9933] uppercase tracking-wider">
              Transformation Benchmark
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold text-white mt-0.5">
              Shrirampur PACS (M.P.) — Model Transformation Stage: 82%
            </h2>
          </div>
          <span className="px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold self-start">
            Grade A Certified
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-xs border border-emerald-400/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-200">Phase 1: Model Bye-laws</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-emerald-100/80 text-[11px]">Adopted for 25+ diversified commercial activities.</p>
            <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 w-full"></div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-xs border border-emerald-400/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-200">Phase 2: Cloud ERP</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-emerald-100/80 text-[11px]">100% data entry complete on National PACS Portal.</p>
            <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-400 w-full"></div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-xs border border-amber-400/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#FF9933]">Phase 3: Service Hub</span>
              <span className="text-[10px] text-[#FF9933] font-bold">80%</span>
            </div>
            <p className="text-emerald-100/80 text-[11px]">CSC, Jan Aushadhi and Drone custom hiring active.</p>
            <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-[#FF9933] w-4/5"></div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/15 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white/90">Phase 4: 1000 MT Storage</span>
              <span className="text-[10px] text-white/70 font-bold">50%</span>
            </div>
            <p className="text-emerald-100/80 text-[11px]">Warehouse shed construction under progress.</p>
            <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-blue-300 w-1/2"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-[#333333]">
            {t.exploreServices} ({filteredServices.length})
          </h2>
          <span className="text-xs text-gray-500 font-medium">Delivered directly in village</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredServices.map((srv) => (
            <div
              key={srv.id}
              onClick={() => setSelectedService(srv)}
              className="bg-white rounded-3xl p-6 border border-[#E8E1D5] hover:border-[#075B46]/60 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="p-3 rounded-2xl bg-emerald-50 text-[#075B46] border border-emerald-200">
                    {getIcon(srv.iconName)}
                  </div>
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5]">
                    {srv.processingTime}
                  </span>
                </div>

                <h3 className="text-base font-extrabold text-[#333333] leading-snug">
                  {srv.title}
                </h3>
                {!isEn && (
                  <p className="text-xs font-semibold text-[#075B46] font-['Noto_Sans_Devanagari']">
                    {srv.titleHi}
                  </p>
                )}

                <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">
                  {srv.description}
                </p>
              </div>

              <div className="pt-3 border-t border-[#E8E1D5] flex items-center justify-between text-xs font-bold text-[#075B46]">
                <span>{t.viewDetails}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Credit Linkage Visual Flowchart */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-900 text-xs font-bold border border-blue-200">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Interactive Credit Linkage Flowchart</span>
          </div>
          <h2 className="text-xl font-bold text-[#333333]">
            NABARD to Farmer: How Subsidized 4% Agricultural Credit Flows
          </h2>
          <p className="text-xs text-gray-500">
            Click on any tier below to explore interest margins, refinancing mechanisms, and prompt subvention benefits.
          </p>
        </div>

        {/* Visual Flow Stepper */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          {CREDIT_LINK_TIERS.map((tier, tIdx) => {
            const isSelected = selectedLinkTier === tier.level;

            return (
              <div
                key={tier.level}
                onClick={() => setSelectedLinkTier(isSelected ? null : tier.level)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 text-center flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-50 border-[#075B46] shadow-md ring-2 ring-emerald-200'
                    : 'bg-[#FDFBF7] border-[#E8E1D5] hover:border-[#075B46]/50'
                }`}
              >
                <div className="space-y-1.5">
                  <div className="w-8 h-8 rounded-full bg-[#075B46] text-white font-extrabold text-xs flex items-center justify-center mx-auto">
                    {tier.level}
                  </div>
                  <h4 className="font-extrabold text-[#333333]">{tier.name}</h4>
                  <p className="text-[10px] text-gray-500">{tier.role}</p>
                </div>

                <div className="p-2 rounded-xl bg-white border border-[#E8E1D5]">
                  <span className="text-[11px] font-black text-[#075B46] block">{tier.rate}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Tier Explainer Box */}
        {selectedLinkTier && (
          <div className="p-4 sm:p-5 bg-emerald-50/70 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1 animate-in fade-in">
            <span className="font-bold text-[#075B46] block">
              Tier {selectedLinkTier} Details: {CREDIT_LINK_TIERS.find(t => t.level === selectedLinkTier)?.name}
            </span>
            <p className="leading-relaxed text-gray-700">
              {CREDIT_LINK_TIERS.find(t => t.level === selectedLinkTier)?.desc}
            </p>
          </div>
        )}
      </section>

      {/* Service Detail Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl border border-[#E8E1D5] animate-in zoom-in-95">
            <div className="flex items-start justify-between border-b border-[#E8E1D5] pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46]">{selectedService.category}</span>
                <h3 className="text-base font-extrabold text-[#333333]">{selectedService.title}</h3>
                {!isEn && <p className="text-xs text-[#075B46] font-semibold">{selectedService.titleHi}</p>}
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-gray-600 leading-relaxed font-medium">{selectedService.description}</p>
              <div className="p-4 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5] space-y-1">
                <span className="font-bold text-[#333333]">Fee / Subsidy:</span>
                <p className="text-gray-600">{selectedService.subsidyOrFee}</p>
              </div>

              <div className="space-y-2">
                <span className="font-bold text-[#333333]">Required Documents:</span>
                <ul className="space-y-1.5 pl-4 list-disc text-gray-600">
                  {selectedService.requiredDocuments.map((doc, idx) => (
                    <li key={idx}>{doc}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-3 border-t border-[#E8E1D5] flex justify-end gap-2">
              <button
                onClick={() => setSelectedService(null)}
                className="px-6 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
