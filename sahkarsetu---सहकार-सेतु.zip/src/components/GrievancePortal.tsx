import React, { useState } from 'react';
import { PageId, LanguageCode, GrievanceRecord } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { MOCK_GRIEVANCES } from '../data/mockData';
import {
  AlertCircle,
  FileCheck,
  Clock,
  CheckCircle2,
  Paperclip,
  Send,
  Search,
  Scale,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  PhoneCall,
  Download,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GrievancePortalProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const GrievancePortal: React.FC<GrievancePortalProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [grievances, setGrievances] = useState<GrievanceRecord[]>(MOCK_GRIEVANCES);
  const [activeTab, setActiveTab] = useState<'list' | 'file' | 'track'>('list');
  const [selectedGrievance, setSelectedGrievance] = useState<GrievanceRecord | null>(MOCK_GRIEVANCES[0]);
  const [searchTrackingId, setSearchTrackingId] = useState('');
  const [fileSuccessId, setFileSuccessId] = useState<string | null>(null);

  // Form State
  const [category, setCategory] = useState('Membership Denial');
  const [complainantName, setComplainantName] = useState('Rameshwar Patel');
  const [mobile, setMobile] = useState('9876543210');
  const [societyName, setSocietyName] = useState('Shrirampur Primary Agricultural Credit Society');
  const [district, setDistrict] = useState('Sehore');
  const [state, setState] = useState('Madhya Pradesh');
  const [description, setDescription] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [attachedProof, setAttachedProof] = useState<string | null>(null);

  const CATEGORIES = [
    'Membership Denial',
    'Dividend Dispute',
    'Election Irregularity',
    'Fertilizer Overpricing / Black Marketing',
    'Loan Recovery Harassment',
    'Service Denial / CSC Rejection',
    'Corruption / Embezzlement',
    'By-law Violation',
    'PMFBY Insurance Claim Delay'
  ];

  const handleFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `GRV-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRecord: GrievanceRecord = {
      id: newId,
      category: category.split(' (')[0],
      complainantName: isAnonymous ? 'Whistleblower (Protected)' : complainantName,
      mobile: isAnonymous ? 'Protected' : mobile,
      societyName,
      district,
      state,
      dateFiled: new Date().toISOString().split('T')[0],
      status: 'Received',
      priority: 'Urgent',
      description: description || 'Grievance submitted regarding cooperative rights violation.',
      slaRemainingDays: 30,
      assignedOfficer: 'District Cooperative Ombudsman & ARCS Desk',
      timeline: [
        { stage: 'Grievance Registered Digitally', date: 'Today', remarks: 'Acknowledgement generated. Statutory 30-day SLA counter initiated.', completed: true },
        { stage: 'Notice Dispatched to Society Secretary', date: 'Pending', remarks: 'Awaiting 7-day explanation response.', completed: false },
        { stage: 'Investigation by Block Inspector', date: 'Pending', remarks: 'On-site verification of records.', completed: false },
        { stage: 'Final Order / Remedy Delivery', date: 'Pending', remarks: 'Mandatory resolution within 30 days.', completed: false }
      ]
    };

    setGrievances([newRecord, ...grievances]);
    setSelectedGrievance(newRecord);
    setFileSuccessId(newId);
    confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
    setActiveTab('track');
  };

  const handleEscalateToOmbudsman = (id: string) => {
    alert(`Case ${id} has been formally escalated to the Central Cooperative Ombudsman (CRCS Office, New Delhi). A priority hearing docket is registered.`);
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-800 text-xs font-bold border border-rose-200">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{t.navGrievance}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featureGrievanceTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featureGrievanceDesc}
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveTab('file')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
            >
              <span>+ {t.fileGrievance}</span>
            </button>
            <button
              onClick={() => onAskAI('How to file a grievance with the Cooperative Ombudsman and what documents are required?')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-emerald-50 text-[#075B46] border border-emerald-200 font-bold text-xs cursor-pointer hover:bg-emerald-100 transition-colors"
            >
              <Sparkles className="w-4 h-4 text-[#FF9933]" />
              <span>{t.askMitra}</span>
            </button>
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-4 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider block">Total Filed</span>
            <span className="text-2xl font-black text-[#333333]">2,842</span>
            <span className="text-[10px] text-[#075B46] font-semibold block">94.2% Resolution Rate</span>
          </div>

          <div className="p-4 bg-amber-50/60 rounded-2xl border border-[#FFE7A3]">
            <span className="text-[10px] text-amber-900 font-bold uppercase tracking-wider block">{t.statusPending}</span>
            <span className="text-2xl font-black text-amber-900">148</span>
            <span className="text-[10px] text-amber-700 font-semibold block">Average Age: 6 Days</span>
          </div>

          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200">
            <span className="text-[10px] text-[#075B46] font-bold uppercase tracking-wider block">{t.statusResolved}</span>
            <span className="text-2xl font-black text-[#075B46]">2,694</span>
            <span className="text-[10px] text-emerald-700 font-semibold block">Direct Member Relief</span>
          </div>

          <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-200">
            <span className="text-[10px] text-blue-900 font-bold uppercase tracking-wider block">Statutory SLA</span>
            <span className="text-2xl font-black text-blue-900">30 Days</span>
            <span className="text-[10px] text-blue-700 font-semibold block">Under MSCS Act 2023</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-t border-[#E8E1D5] pt-3">
          <button
            onClick={() => setActiveTab('list')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'list' ? 'bg-[#075B46] text-white shadow-2xs' : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
            }`}
          >
            {t.myComplaints}
          </button>
          <button
            onClick={() => setActiveTab('file')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'file' ? 'bg-rose-600 text-white shadow-2xs' : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
            }`}
          >
            {t.fileGrievance}
          </button>
          <button
            onClick={() => setActiveTab('track')}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'track' ? 'bg-[#333333] text-white shadow-2xs' : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
            }`}
          >
            {t.trackApplication}
          </button>
        </div>
      </div>

      {/* Tab: File New Grievance */}
      {activeTab === 'file' && (
        <form onSubmit={handleFileSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-sm space-y-6">
          <div className="space-y-1 border-b border-[#E8E1D5] pb-3">
            <h2 className="text-lg font-bold text-[#333333]">
              {t.fileGrievance}
            </h2>
            <p className="text-xs text-gray-500">
              Your petition will be assigned directly to the District Assistant Registrar & Cooperative Ombudsman.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5 sm:col-span-2">
              <label className="font-bold text-[#555555]">{t.formCategory}: *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
              >
                {CATEGORIES.map((cat, idx) => (
                  <option key={idx} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">{t.formApplicantName}:</label>
              <input
                type="text"
                value={complainantName}
                onChange={(e) => setComplainantName(e.target.value)}
                disabled={isAnonymous}
                required
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">{t.formMobile}:</label>
              <input
                type="tel"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                disabled={isAnonymous}
                required
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">{t.formPacsName}:</label>
              <input
                type="text"
                value={societyName}
                onChange={(e) => setSocietyName(e.target.value)}
                required
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">District & State:</label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
                />
                <input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333]"
                />
              </div>
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <label className="font-bold text-[#555555]">{t.formDescription}: *</label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Please describe the violation, date, society officials involved, and relevant details..."
                required
                className="w-full p-3.5 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-medium text-[#333333]"
              ></textarea>
            </div>

            <div className="sm:col-span-2 space-y-3">
              {/* Evidence Attachment */}
              <div className="p-4 rounded-2xl border border-dashed border-[#D4C8B5] bg-[#FDFBF7] flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-white border border-[#E8E1D5] text-[#075B46]">
                    <Paperclip className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#333333]">Attach Evidence / Documents</p>
                    <p className="text-[11px] text-gray-500">Receipts, passbook copies, rejection letters, or photos (PDF/JPG up to 5MB)</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAttachedProof('membership_denial_proof.pdf')}
                  className="px-4 py-2 rounded-full bg-white border border-[#E8E1D5] hover:bg-[#FDFBF7] text-[#333333] text-xs font-bold cursor-pointer"
                >
                  {attachedProof ? `Attached: ${attachedProof}` : 'Choose File'}
                </button>
              </div>

              {/* Whistleblower Protection */}
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="w-4 h-4 text-[#075B46] rounded-sm accent-[#075B46]"
                />
                <span className="text-xs font-semibold text-[#555555]">
                  Whistleblower Protection — Keep my identity confidential and restricted to the Ombudsman only.
                </span>
              </label>
            </div>
          </div>

          <div className="pt-3 border-t border-[#E8E1D5] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setActiveTab('list')}
              className="px-5 py-2.5 rounded-full bg-[#FDFBF7] hover:bg-white text-[#555555] border border-[#E8E1D5] font-bold text-xs cursor-pointer"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{t.submitGrievance}</span>
            </button>
          </div>
        </form>
      )}

      {/* Tab: Grievance List */}
      {activeTab === 'list' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: List of cases */}
          <div className="lg:col-span-6 space-y-3">
            <h2 className="text-sm font-bold text-[#333333]">
              {t.myComplaints} ({grievances.length})
            </h2>

            {grievances.map((grv) => {
              const isSelected = selectedGrievance?.id === grv.id;

              return (
                <div
                  key={grv.id}
                  onClick={() => setSelectedGrievance(grv)}
                  className={`bg-white rounded-3xl p-5 border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[#075B46] shadow-sm ring-1 ring-[#075B46]'
                      : 'border-[#E8E1D5] hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-bold text-gray-400">
                        {grv.id} • {grv.dateFiled}
                      </span>
                      <h3 className="text-xs sm:text-sm font-bold text-[#333333] mt-0.5">
                        {grv.category}
                      </h3>
                      <p className="text-[11px] text-gray-500 font-medium truncate max-w-[280px]">
                        {grv.societyName}
                      </p>
                    </div>

                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        grv.status === 'Resolved'
                          ? 'bg-emerald-100 text-[#075B46]'
                          : grv.status === 'Hearing Scheduled'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {grv.status}
                    </span>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-[#E8E1D5] flex items-center justify-between text-[11px] text-[#555555]">
                    <span>SLA: {grv.slaRemainingDays} Days Remaining</span>
                    <span className="font-bold text-[#075B46] flex items-center gap-1">
                      <span>View Timeline</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Case Timeline & Details */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-7 border border-[#E8E1D5] shadow-xs space-y-5">
            {selectedGrievance ? (
              <div className="space-y-4 text-xs">
                <div className="flex items-start justify-between border-b border-[#E8E1D5] pb-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46]">Case Details</span>
                    <h3 className="text-base font-extrabold text-[#333333]">{selectedGrievance.id}</h3>
                    <p className="text-xs font-semibold text-[#555555]">{selectedGrievance.category}</p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#FDFBF7] text-[#333333] border border-[#E8E1D5] text-xs font-bold">
                    {selectedGrievance.priority} Priority
                  </span>
                </div>

                <div className="p-4 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5] space-y-1">
                  <span className="font-bold text-[#333333] block">Grievance Summary:</span>
                  <p className="text-gray-600 leading-relaxed">{selectedGrievance.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-3 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
                    <span className="text-gray-400 block font-semibold">Assigned Authority:</span>
                    <span className="font-bold text-[#333333]">{selectedGrievance.assignedOfficer}</span>
                  </div>
                  <div className="p-3 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
                    <span className="text-gray-400 block font-semibold">Jurisdiction:</span>
                    <span className="font-bold text-[#333333]">{selectedGrievance.district}, {selectedGrievance.state}</span>
                  </div>
                </div>

                {/* Timeline Stepper */}
                <div className="space-y-3 pt-2">
                  <span className="font-bold text-[#333333] block text-xs">
                    Live Investigation Timeline:
                  </span>

                  <div className="space-y-3 pl-2 border-l-2 border-[#075B46] ml-2">
                    {selectedGrievance.timeline.map((step, idx) => (
                      <div key={idx} className="relative pl-4 space-y-0.5">
                        <div
                          className={`absolute -left-[13px] top-0.5 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center text-[9px] ${
                            step.completed ? 'bg-[#075B46] text-white' : 'bg-stone-300 text-stone-600'
                          }`}
                        >
                          {step.completed ? '✓' : idx + 1}
                        </div>
                        <div className="flex items-center justify-between">
                          <span className={`font-bold ${step.completed ? 'text-[#333333]' : 'text-gray-400'}`}>
                            {step.stage}
                          </span>
                          <span className="text-[10px] text-gray-400 font-medium">{step.date}</span>
                        </div>
                        <p className="text-[11px] text-gray-500">{step.remarks}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-[#E8E1D5] flex flex-wrap items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      alert(`Acknowledgement PDF for ${selectedGrievance.id} downloaded successfully!`);
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-full border border-[#E8E1D5] text-[#333333] text-xs font-bold hover:bg-[#FDFBF7] cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Receipt</span>
                  </button>

                  <button
                    onClick={() => handleEscalateToOmbudsman(selectedGrievance.id)}
                    className="px-4 py-2 rounded-full bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold hover:bg-rose-100 cursor-pointer"
                  >
                    Escalate to CRCS Ombudsman
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-xs text-gray-500">Select a grievance to view timeline.</p>
            )}
          </div>
        </div>
      )}

      {/* Tab: Track by ID */}
      {activeTab === 'track' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
          <div className="max-w-md mx-auto space-y-3 text-center">
            <h2 className="text-base font-bold text-[#333333]">
              {t.trackApplication}
            </h2>
            <p className="text-xs text-gray-500">
              e.g., GRV-2026-9481, GRV-2026-8812
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={searchTrackingId}
                onChange={(e) => setSearchTrackingId(e.target.value)}
                placeholder="GRV-2026-XXXX"
                className="flex-1 p-3 text-xs font-bold rounded-full border border-[#E8E1D5] bg-[#FDFBF7] text-[#333333] focus:outline-emerald-700"
              />
              <button
                onClick={() => {
                  const match = grievances.find(g => g.id.toLowerCase() === searchTrackingId.trim().toLowerCase());
                  if (match) {
                    setSelectedGrievance(match);
                    setActiveTab('list');
                  } else {
                    alert('Tracking ID not found. Displaying default active case.');
                    setActiveTab('list');
                  }
                }}
                className="px-6 py-3 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white text-xs font-bold cursor-pointer transition-colors"
              >
                {t.trackStatus}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
