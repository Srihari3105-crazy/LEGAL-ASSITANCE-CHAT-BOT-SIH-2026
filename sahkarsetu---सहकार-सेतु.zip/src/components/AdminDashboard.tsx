import React, { useState } from 'react';
import { LanguageCode, UserRole } from '../types';
import { MOCK_GRIEVANCES, ADMIN_METRICS } from '../data/mockData';
import { UI_TRANSLATIONS } from '../data/translations';
import {
  ShieldCheck,
  Download,
  ClipboardList
} from 'lucide-react';

interface AdminDashboardProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentLanguage
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [activeRole, setActiveRole] = useState<UserRole>('officer');
  const [grievanceStatusFilter, setGrievanceStatusFilter] = useState<string>('All');
  const [searchFilter] = useState<string>('');

  // Audit Checklist State (storing item keys and completion state)
  const [auditChecklist, setAuditChecklist] = useState([
    { id: 1, key: 'auditItem1' as const, checked: true, score: 20 },
    { id: 2, key: 'auditItem2' as const, checked: true, score: 25 },
    { id: 3, key: 'auditItem3' as const, checked: true, score: 25 },
    { id: 4, key: 'auditItem4' as const, checked: false, score: 15 },
    { id: 5, key: 'auditItem5' as const, checked: true, score: 15 }
  ]);

  const complianceScore = auditChecklist.reduce((acc, item) => item.checked ? acc + item.score : acc, 0);

  const STATE_RANKINGS = [
    { rank: 1, stateKey: 'stateMaharashtra' as const, stateDefault: 'Maharashtra', computerized: '98.4%', activePacs: '21,480', healthGrade: 'A+' },
    { rank: 2, stateKey: 'stateGujarat' as const, stateDefault: 'Gujarat', computerized: '96.2%', activePacs: '10,210', healthGrade: 'A+' },
    { rank: 3, stateKey: 'stateMadhyaPradesh' as const, stateDefault: 'Madhya Pradesh', computerized: '91.8%', activePacs: '4,520', healthGrade: 'A' },
    { rank: 4, stateKey: 'stateUttarPradesh' as const, stateDefault: 'Uttar Pradesh', computerized: '88.5%', activePacs: '7,890', healthGrade: 'B+' },
    { rank: 5, stateKey: 'stateTamilNadu' as const, stateDefault: 'Tamil Nadu', computerized: '87.1%', activePacs: '4,450', healthGrade: 'B+' }
  ];

  const getLocalizedCategory = (category: string) => {
    switch (category) {
      case 'Membership Denial':
        return t.catMembershipDenial || category;
      case 'Dividend Dispute':
        return t.catDividendDispute || category;
      case 'Fertilizer Overpricing':
        return t.catFertilizerOverpricing || category;
      case 'Credit Disbursement Delay':
        return t.catCreditDisbursement || category;
      case 'Election Dispute':
        return t.catElectionDispute || category;
      default:
        return category;
    }
  };

  const filteredGrievances = MOCK_GRIEVANCES.filter(g => {
    const matchesStatus = grievanceStatusFilter === 'All' || g.status === grievanceStatusFilter;
    const matchesSearch = g.complainantName.toLowerCase().includes(searchFilter.toLowerCase()) ||
                          g.id.toLowerCase().includes(searchFilter.toLowerCase()) ||
                          g.societyName.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const toggleChecklist = (id: number) => {
    setAuditChecklist(auditChecklist.map(item => item.id === id ? { ...item, checked: !item.checked } : item));
  };

  const handleIssueNotice = (societyName: string, id: string) => {
    const alertMsg = (t.noticeIssuedAlert || 'Formal notice issued to {society} for case {id}')
      .replace('{society}', societyName)
      .replace('{id}', id);
    alert(alertMsg);
  };

  const handleExport = () => {
    alert(t.exportSuccessAlert || 'Grievance log exported as XLSX/PDF successfully.');
  };

  const handleSubmitAudit = () => {
    const alertMsg = (t.auditSubmittedAlert || 'Statutory Audit Inspection Report finalized with compliance score {score}%. Transmitted to State Registrar.')
      .replace('{score}', complianceScore.toString());
    alert(alertMsg);
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.adminHeaderBadge}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.adminTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.adminSubtitle}
            </p>
          </div>

          {/* Role Switcher */}
          <div className="space-y-1 self-start sm:self-center">
            <label className="text-[10px] font-bold text-gray-500 uppercase block">{t.officerView || t.officerRole}</label>
            <select
              value={activeRole}
              onChange={(e) => setActiveRole(e.target.value as UserRole)}
              className="p-2.5 px-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] text-xs font-bold text-[#333333] focus:outline-hidden"
            >
              <option value="officer">{t.roleOfficer}</option>
              <option value="pacs_admin">{t.rolePacsAdmin}</option>
              <option value="super_admin">{t.roleSuperAdmin}</option>
              <option value="kiosk_operator">{t.roleKioskOperator}</option>
            </select>
          </div>
        </div>

        {/* National Metric KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 pt-3 border-t border-[#E8E1D5]">
          <div className="p-4 sm:p-5 bg-[#075B46] text-white rounded-3xl space-y-1 border border-[#0B5D4B]">
            <span className="text-[10px] text-emerald-200 font-bold uppercase block">{t.metricTotalPacs}</span>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#FF9933]">
              {ADMIN_METRICS.totalPACSComputerized.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-emerald-200 font-semibold block">{t.metricTotalPacsSub}</span>
          </div>

          <div className="p-4 sm:p-5 bg-[#FDFBF7] rounded-3xl border border-[#E8E1D5] space-y-1">
            <span className="text-[10px] text-gray-500 font-bold uppercase block">{t.metricActiveGrievances}</span>
            <div className="text-2xl sm:text-3xl font-extrabold text-rose-600">
              {ADMIN_METRICS.activeGrievances}
            </div>
            <span className="text-[10px] text-gray-500 font-semibold block">{t.metricActiveGrievancesSub}</span>
          </div>

          <div className="p-4 sm:p-5 bg-emerald-50/70 rounded-3xl border border-emerald-200 space-y-1">
            <span className="text-[10px] text-[#075B46] font-bold uppercase block">{t.metricCropClaimsSettled}</span>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#075B46]">
              ₹{ADMIN_METRICS.cropClaimsSettledAmountCr} Cr
            </div>
            <span className="text-[10px] text-[#075B46] font-semibold block">{t.metricCropClaimsSettledSub}</span>
          </div>

          <div className="p-4 sm:p-5 bg-blue-50/70 rounded-3xl border border-blue-200 space-y-1">
            <span className="text-[10px] text-blue-900 font-bold uppercase block">{t.metricGrainStorageCapacity}</span>
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-900">
              {ADMIN_METRICS.grainStorageCapacityMT.toLocaleString('en-IN')} MT
            </div>
            <span className="text-[10px] text-blue-700 font-semibold block">{t.metricGrainStorageCapacitySub}</span>
          </div>
        </div>
      </div>

      {/* Main Administrative Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Grievance Case Management Table */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-7 border border-[#E8E1D5] shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E8E1D5] pb-3">
            <div>
              <span className="text-[10px] font-bold uppercase text-[#075B46] tracking-wider">{t.queueOmbudsman}</span>
              <h2 className="text-base font-extrabold text-[#333333]">
                {t.grievanceManagementTitle} ({filteredGrievances.length})
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={grievanceStatusFilter}
                onChange={(e) => setGrievanceStatusFilter(e.target.value)}
                className="p-2 rounded-xl border border-[#E8E1D5] text-xs font-semibold bg-[#FDFBF7] text-[#333333]"
              >
                <option value="All">{t.filterAllStatus}</option>
                <option value="Under Investigation">{t.filterUnderInvestigation}</option>
                <option value="Hearing Scheduled">{t.filterHearingScheduled}</option>
                <option value="Resolved">{t.filterResolved}</option>
              </select>

              <button
                onClick={handleExport}
                className="p-2 rounded-xl border border-[#E8E1D5] bg-[#FDFBF7] text-[#555555] hover:bg-white cursor-pointer"
                title={t.exportTooltip || t.exportBtn}
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-[#FDFBF7] text-[#555555] border-b border-[#E8E1D5]">
                  <th className="p-3 font-bold">{t.colCaseId}</th>
                  <th className="p-3 font-bold">{t.colComplainantSociety}</th>
                  <th className="p-3 font-bold">{t.colCategory}</th>
                  <th className="p-3 font-bold">{t.colSla}</th>
                  <th className="p-3 font-bold">{t.colAction}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E8E1D5] text-[#333333]">
                {filteredGrievances.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-gray-500 font-medium">
                      {t.noGrievancesFound || 'No grievance cases matching criteria.'}
                    </td>
                  </tr>
                ) : (
                  filteredGrievances.map((g) => (
                    <tr key={g.id} className="hover:bg-amber-50/30 transition-colors">
                      <td className="p-3 font-extrabold text-[#075B46]">{g.id}</td>
                      <td className="p-3">
                        <div className="font-bold text-[#333333]">{g.complainantName}</div>
                        <div className="text-[10px] text-gray-500 truncate max-w-[140px]">{g.societyName}</div>
                      </td>
                      <td className="p-3 font-medium text-gray-600">{getLocalizedCategory(g.category)}</td>
                      <td className="p-3">
                        <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 font-bold text-[10px]">
                          {g.slaRemainingDays} {t.daysRemainingSuffix}
                        </span>
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => handleIssueNotice(g.societyName, g.id)}
                          className="px-3 py-1.5 rounded-full bg-[#075B46] text-white font-bold text-[10px] hover:bg-[#0B5D4B] transition-colors cursor-pointer"
                        >
                          {t.actionIssueNotice}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Statutory Audit & Compliance Checklist */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 border border-[#E8E1D5] shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
              <div className="flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-[#075B46]" />
                <h2 className="text-base font-extrabold text-[#333333]">
                  {t.auditChecklistTitle}
                </h2>
              </div>
              <span className={`text-xs font-black px-3 py-1 rounded-full border ${
                complianceScore >= 80 ? 'bg-emerald-50 text-[#075B46] border-emerald-200' : 'bg-amber-50 text-amber-900 border-amber-200'
              }`}>
                {t.scoreBadgeLabel || 'Score'}: {complianceScore}/100
              </span>
            </div>

            <p className="text-xs text-gray-500">
              {t.auditChecklistSub}
            </p>

            <div className="space-y-2.5 pt-1">
              {auditChecklist.map((item) => (
                <div
                  key={item.id}
                  onClick={() => toggleChecklist(item.id)}
                  className={`p-3.5 rounded-2xl border text-xs cursor-pointer transition-all flex items-start gap-2.5 ${
                    item.checked
                      ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950 shadow-2xs'
                      : 'bg-[#FDFBF7] border-[#E8E1D5] text-[#555555] hover:border-gray-400'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={() => {}}
                    className="mt-0.5 rounded-sm accent-[#075B46]"
                  />
                  <div className="flex-1 font-medium leading-relaxed">
                    {t[item.key] || item.key}
                  </div>
                  <span className="text-[10px] font-bold text-gray-400">+{item.score}pts</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-[#E8E1D5]">
            <button
              onClick={handleSubmitAudit}
              className="w-full py-3 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs text-center transition-colors cursor-pointer shadow-xs"
            >
              {t.submitAuditReport}
            </button>
          </div>
        </div>
      </div>

      {/* State-wise PACS Health & Computerization Ranking Matrix */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
          <div>
            <span className="text-[10px] font-bold uppercase text-[#075B46] tracking-wider">{t.statePerformanceIndex}</span>
            <h2 className="text-lg font-extrabold text-[#333333]">
              {t.stateRankingTitle}
            </h2>
          </div>
          <span className="text-xs text-gray-500 font-medium">{t.syncedWithErp}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3.5 text-xs">
          {STATE_RANKINGS.map((sr) => (
            <div key={sr.rank} className="p-5 rounded-3xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="w-6 h-6 rounded-full bg-[#075B46] text-white font-bold text-[10px] flex items-center justify-center">
                  #{sr.rank}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-[#075B46] border border-emerald-200 font-bold text-[10px]">
                  {t.labelGrade} {sr.healthGrade}
                </span>
              </div>
              <h4 className="font-extrabold text-[#333333] text-sm">{t[sr.stateKey] || sr.stateDefault}</h4>
              <div className="space-y-1 text-[11px] text-gray-500">
                <div>{t.labelComputerized}: <strong className="text-[#333333]">{sr.computerized}</strong></div>
                <div>{t.labelActivePacs}: <strong className="text-[#333333]">{sr.activePacs}</strong></div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
