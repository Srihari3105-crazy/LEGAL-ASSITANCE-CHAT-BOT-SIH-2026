import React, { useState } from 'react';
import { PageId, LanguageCode, SchemeItem } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { GOVT_SCHEMES } from '../data/mockData';
import {
  Landmark,
  Search,
  Filter,
  CheckCircle2,
  FileText,
  Clock,
  Sparkles,
  Users,
  ShieldAlert,
  ArrowRight,
  X,
  HelpCircle,
  Award,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SchemesPageProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const SchemesPage: React.FC<SchemesPageProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTarget, setSelectedTarget] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [eligibilityModalScheme, setEligibilityModalScheme] = useState<SchemeItem | null>(null);
  const [applyModalScheme, setApplyModalScheme] = useState<SchemeItem | null>(null);
  const [applySuccess, setApplySuccess] = useState<boolean>(false);

  // Wizard state for Eligibility Checker
  const [userRole, setUserRole] = useState<'farmer' | 'pacs' | 'women' | 'youth'>('farmer');
  const [hasLand, setHasLand] = useState<boolean>(true);
  const [isPacsMember, setIsPacsMember] = useState<boolean>(true);

  const TARGET_GROUPS = [
    { id: 'all', label: t.all },
    { id: 'farmer', label: '🧑‍🌾 Farmers' },
    { id: 'pacs', label: '🏛️ PACS Societies' },
    { id: 'women', label: '👩 Women & SHGs' },
    { id: 'youth', label: '🎓 Rural Youth' },
  ];

  const CATEGORIES = ['all', 'Digitization', 'Infrastructure', 'Credit & Finance', 'Training & Capacity'];

  const filteredSchemes = GOVT_SCHEMES.filter((scheme) => {
    const matchesTarget = selectedTarget === 'all' || scheme.targetGroup.includes(selectedTarget as any);
    const matchesCategory = selectedCategory === 'all' || scheme.category === selectedCategory;
    const matchesSearch = 
      scheme.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.titleHi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.subsidyAmount.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTarget && matchesCategory && matchesSearch;
  });

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setApplySuccess(true);
    confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
    setTimeout(() => {
      setApplySuccess(false);
      setApplyModalScheme(null);
    }, 2800);
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <Landmark className="w-3.5 h-3.5" />
              <span>{t.navSchemes}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featureSchemesTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featureSchemesDesc}
            </p>
          </div>

          <button
            onClick={() => onAskAI('Tell me about Ministry of Cooperation schemes and subsidies')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs shrink-0 shadow-xs cursor-pointer transition-colors"
          >
            <Sparkles className="w-4 h-4 text-[#FF9933]" />
            <span>{t.askMitra}</span>
          </button>
        </div>

        {/* Filters */}
        <div className="pt-2 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`${t.search}...`}
              className="w-full pl-11 pr-4 py-3 text-xs sm:text-sm bg-[#FDFBF7] border border-[#E8E1D5] text-[#333333] rounded-full focus:outline-hidden focus:border-[#075B46] focus:bg-white transition-all"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {TARGET_GROUPS.map((tg) => (
              <button
                key={tg.id}
                onClick={() => setSelectedTarget(tg.id)}
                className={`px-4 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedTarget === tg.id
                    ? 'bg-[#075B46] text-white shadow-2xs'
                    : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
                }`}
              >
                {tg.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Schemes Grid */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-[#333333]">
            {t.featureSchemesTitle} ({filteredSchemes.length})
          </h2>
          <span className="text-xs text-gray-500 font-medium">Pan-India Implementation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredSchemes.map((scheme) => (
            <div
              key={scheme.id}
              className="bg-white rounded-3xl border border-[#E8E1D5] hover:border-[#075B46]/60 p-6 sm:p-7 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-5"
            >
              <div className="space-y-3.5">
                <div className="flex items-start justify-between gap-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
                    {scheme.category}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-900 text-[11px] font-bold border border-amber-200">
                    {scheme.status}
                  </span>
                </div>

                <div>
                  <h3 className="text-base sm:text-lg font-extrabold text-[#333333] leading-snug">
                    {scheme.title}
                  </h3>
                  <p className="text-[11px] text-gray-500 mt-1 font-medium">
                    {scheme.ministry}
                  </p>
                </div>

                {/* Subsidy Highlight */}
                <div className="p-4 rounded-2xl bg-amber-50/70 border border-[#FFE7A3] text-xs space-y-1">
                  <span className="text-[10px] uppercase font-bold text-amber-900 tracking-wider block">Financial Assistance:</span>
                  <p className="font-bold text-[#333333]">{scheme.subsidyAmount}</p>
                </div>

                {/* Benefits Bullet Points */}
                <div className="space-y-1.5 text-xs text-gray-700">
                  <span className="font-bold text-[#333333] text-[11px] block">Key Benefits:</span>
                  <ul className="space-y-1.5 pl-4 list-disc text-[11px] text-gray-600">
                    {scheme.benefits.slice(0, 3).map((b, bIdx) => (
                      <li key={bIdx}>{b}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-[#E8E1D5] flex flex-wrap items-center justify-between gap-2">
                <button
                  onClick={() => setEligibilityModalScheme(scheme)}
                  className="px-4 py-2 rounded-full bg-[#FDFBF7] hover:bg-white text-[#333333] border border-[#E8E1D5] text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#075B46]" />
                  <span>{t.eligibility}</span>
                </button>

                <button
                  onClick={() => setApplyModalScheme(scheme)}
                  className="px-5 py-2 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
                >
                  <span>{t.applyOnline}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Eligibility Modal Wizard */}
      {eligibilityModalScheme && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl border border-[#E8E1D5] animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46]">Instant Eligibility Check</span>
                <h3 className="text-base font-extrabold text-[#333333]">{eligibilityModalScheme.title}</h3>
              </div>
              <button
                onClick={() => setEligibilityModalScheme(null)}
                className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 text-emerald-950 space-y-1">
                <span className="font-bold text-[#075B46] block">Score: 95% Match (Eligible)</span>
                <p className="text-[11px] text-emerald-800">
                  You meet the primary criteria defined under the national guidelines.
                </p>
              </div>

              <div className="space-y-2">
                <span className="font-bold text-[#333333] block">Required Documents Checklist:</span>
                <ul className="space-y-2">
                  {eligibilityModalScheme.requiredDocs.map((doc, dIdx) => (
                    <li key={dIdx} className="flex items-center gap-2.5 p-3 bg-[#FDFBF7] rounded-xl border border-[#E8E1D5]">
                      <CheckCircle2 className="w-4 h-4 text-[#075B46] shrink-0" />
                      <span className="text-[#333333] font-medium">{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-3 border-t border-[#E8E1D5] flex items-center justify-end gap-2.5">
              <button
                onClick={() => setEligibilityModalScheme(null)}
                className="px-5 py-2.5 rounded-full bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] font-bold text-xs cursor-pointer hover:bg-white"
              >
                {t.close}
              </button>
              <button
                onClick={() => {
                  const scheme = eligibilityModalScheme;
                  setEligibilityModalScheme(null);
                  setApplyModalScheme(scheme);
                }}
                className="px-6 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs cursor-pointer"
              >
                {t.applyOnline}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Apply Form Modal */}
      {applyModalScheme && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl border border-[#E8E1D5] animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46]">Direct Application Portal</span>
                <h3 className="text-base font-extrabold text-[#333333]">{applyModalScheme.title}</h3>
              </div>
              <button
                onClick={() => setApplyModalScheme(null)}
                className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {applySuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-[#075B46] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-[#333333]">Application Submitted Successfully!</h4>
                <p className="text-xs text-gray-600">
                  Application Reference ID: <strong className="text-[#075B46]">APP-MOC-2026-7841</strong>
                </p>
                <p className="text-[11px] text-gray-500">
                  A confirmation SMS has been sent to registered mobile.
                </p>
              </div>
            ) : (
              <form onSubmit={handleApplySubmit} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="font-bold text-[#555555]">{t.formApplicantName}:</label>
                  <input
                    type="text"
                    defaultValue="Rameshwar Patel / Shrirampur PACS"
                    required
                    className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-medium text-[#333333]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="font-bold text-[#555555]">Aadhaar / Member ID:</label>
                    <input
                      type="text"
                      defaultValue="XXXX-XXXX-8492"
                      required
                      className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-medium text-[#333333]"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="font-bold text-[#555555]">{t.formMobile}:</label>
                    <input
                      type="tel"
                      defaultValue="9876543210"
                      required
                      className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-medium text-[#333333]"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-[#555555]">{t.formPacsName}:</label>
                  <input
                    type="text"
                    defaultValue="Sehore DCCB Main Branch (IFSC: MPCO000104)"
                    required
                    className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-medium text-[#333333]"
                  />
                </div>

                <div className="p-3.5 bg-amber-50/70 rounded-2xl border border-[#FFE7A3] text-amber-950 text-[11px]">
                  ✓ Documents will be fetched automatically via DigiLocker.
                </div>

                <div className="pt-3 border-t border-[#E8E1D5] flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setApplyModalScheme(null)}
                    className="px-5 py-2.5 rounded-full bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] font-bold text-xs cursor-pointer hover:bg-white"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs cursor-pointer"
                  >
                    {t.submitGrievance || 'Submit'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
