import React from 'react';
import { PageId, LanguageCode } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import {
  Home,
  LayoutDashboard,
  MessageSquareText,
  Scale,
  Landmark,
  ShieldCheck,
  AlertCircle,
  Calculator,
  Store,
  Mic,
  ShieldAlert,
  HelpCircle,
  FileText
} from 'lucide-react';

interface SidebarProps {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  currentLanguage: LanguageCode;
  onOpenHelp?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  setCurrentPage,
  currentLanguage,
  onOpenHelp
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  const NAV_ITEMS: { id: PageId; label: string; icon: React.FC<{ className?: string }>; badge?: string; badgeColor?: string }[] = [
    { id: 'landing', label: t.navHome, icon: Home },
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard, badge: t.active, badgeColor: 'bg-emerald-100 text-emerald-800' },
    { id: 'chat', label: t.navChat, icon: MessageSquareText, badge: 'AI Live', badgeColor: 'bg-amber-100 text-amber-800' },
    { id: 'laws', label: t.navLaws, icon: Scale },
    { id: 'schemes', label: t.navSchemes, icon: Landmark, badge: '5 New', badgeColor: 'bg-blue-100 text-blue-800' },
    { id: 'pmfby', label: t.navPmfby, icon: ShieldCheck },
    { id: 'grievance', label: t.navGrievance, icon: AlertCircle, badge: 'SLA: 30d', badgeColor: 'bg-rose-100 text-rose-800' },
    { id: 'financial', label: t.navFinancial, icon: Calculator },
    { id: 'pacs', label: t.navPacs, icon: Store },
    { id: 'voice', label: t.navVoice, icon: Mic, badge: t.liveAudio, badgeColor: 'bg-purple-100 text-purple-800' },
    { id: 'admin', label: t.navAdmin, icon: ShieldAlert, badge: t.officerBadge, badgeColor: 'bg-slate-100 text-slate-700' },
  ];

  return (
    <aside className="w-64 bg-[#FDFBF7] border-r border-[#E8E1D5] flex flex-col shrink-0 min-h-[calc(100vh-80px)] p-4 gap-2 select-none">
      {/* Navigation section header */}
      <div className="px-3 py-1">
        <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
          {t.mainMenu}
        </span>
      </div>

      {/* Nav List */}
      <nav className="flex-1 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          return (
            <button
              key={item.id}
              id={`sidebar-nav-${item.id}`}
              onClick={() => setCurrentPage(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs transition-all group cursor-pointer ${
                isActive
                  ? 'bg-[#075B46] text-white font-bold shadow-xs'
                  : 'text-[#555555] hover:bg-white hover:text-[#333333] font-medium transition-colors'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`p-1.5 rounded-xl transition-colors ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-white text-gray-500 group-hover:text-[#075B46] border border-[#E8E1D5]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span className="truncate text-left">
                  {item.label}
                </span>
              </div>

              {item.badge && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : item.badgeColor || 'bg-white text-gray-600 border border-[#E8E1D5]'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* SahkarVaani Voice / Rural Support Box */}
      <div className="mt-auto bg-white p-4 rounded-3xl border border-[#E8E1D5] shadow-xs">
        <div className="flex items-center gap-1.5 mb-1.5">
          <span className="w-2 h-2 rounded-full bg-[#075B46] animate-pulse"></span>
          <p className="text-[10px] font-bold text-[#075B46] uppercase tracking-wider">
            {t.voiceVaani}
          </p>
        </div>
        <p className="text-[11px] text-gray-500 mb-3 leading-relaxed">
          {t.sidebarVoicePrompt}
        </p>
        <button
          onClick={() => setCurrentPage('voice')}
          className="w-full bg-[#FF9933] text-white py-2 px-3 rounded-full flex items-center justify-center gap-2 text-xs font-bold hover:bg-[#e68a2e] transition-colors shadow-xs cursor-pointer"
        >
          <Mic className="w-3.5 h-3.5" />
          <span>{t.listenAndSpeak}</span>
        </button>
      </div>

      {/* Quick Helpline Footer in Sidebar */}
      <div className="px-2 pt-2 border-t border-[#E8E1D5] text-[10px] text-gray-500 flex items-center justify-between font-medium">
        <span>{t.quickHelpline}</span>
        <span className="text-[#075B46] font-bold">24x7</span>
      </div>
    </aside>
  );
};
