import React, { useState } from 'react';
import { PageId, LanguageCode } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import {
  Calculator,
  TrendingUp,
  Percent,
  Landmark,
  Users,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  PiggyBank,
  CreditCard,
  Building,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface FinancialLiteracyPageProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const FinancialLiteracyPage: React.FC<FinancialLiteracyPageProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const isEn = currentLanguage === 'en';

  // Loan Calculator State
  const [loanType, setLoanType] = useState<'kcc' | 'term' | 'tractor'>('kcc');
  const [principal, setPrincipal] = useState<number>(100000);
  const [tenureMonths, setTenureMonths] = useState<number>(12);
  const [interestRate, setInterestRate] = useState<number>(7.0); // Base 7%

  // Subvention Calculation
  const isPromptPayer = true; // Prompt Repayment Incentive (3% GOI subvention)
  const effectiveRate = loanType === 'kcc' ? Math.max(0, interestRate - 3.0) : interestRate;
  const monthlyRate = effectiveRate / 12 / 100;
  const emi = tenureMonths > 0 && monthlyRate > 0
    ? Math.round((principal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) / (Math.pow(1 + monthlyRate, tenureMonths) - 1))
    : Math.round(principal / tenureMonths);
  const totalRepayment = emi * tenureMonths;
  const totalInterest = totalRepayment - principal;
  const subventionSavings = loanType === 'kcc' ? Math.round((principal * 0.03 * (tenureMonths / 12))) : 0;

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <Calculator className="w-3.5 h-3.5" />
              <span>{t.navLiteracy}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featureLiteracyTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featureLiteracyDesc}
            </p>
          </div>

          <button
            onClick={() => onAskAI('How does the Kisan Credit Card (KCC) 4% interest rate and 3% prompt repayment subvention work?')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs shrink-0 shadow-xs cursor-pointer transition-colors"
          >
            <Sparkles className="w-4 h-4 text-[#FF9933]" />
            <span>{t.askMitra}</span>
          </button>
        </div>
      </div>

      {/* Interactive Loan & KCC EMI Calculator */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E8E1D5] pb-3">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-[#075B46]" />
            <h2 className="text-base sm:text-lg font-extrabold text-[#333333]">
              Agricultural Loan & KCC EMI Calculator
            </h2>
          </div>
          <span className="text-xs font-bold text-[#075B46] bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            3% Govt Subvention Active
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Controls */}
          <div className="lg:col-span-7 space-y-5 text-xs">
            <div className="space-y-2">
              <label className="font-bold text-[#333333]">Loan Product:</label>
              <div className="grid grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => { setLoanType('kcc'); setInterestRate(7.0); setTenureMonths(12); }}
                  className={`p-3 rounded-2xl font-bold border transition-all cursor-pointer ${
                    loanType === 'kcc' ? 'bg-emerald-50 border-[#075B46] text-[#075B46] shadow-2xs' : 'bg-[#FDFBF7] border-[#E8E1D5] text-[#555555] hover:border-gray-400'
                  }`}
                >
                  KCC Crop Loan (4% Net)
                </button>
                <button
                  type="button"
                  onClick={() => { setLoanType('term'); setInterestRate(8.5); setTenureMonths(36); }}
                  className={`p-3 rounded-2xl font-bold border transition-all cursor-pointer ${
                    loanType === 'term' ? 'bg-emerald-50 border-[#075B46] text-[#075B46] shadow-2xs' : 'bg-[#FDFBF7] border-[#E8E1D5] text-[#555555] hover:border-gray-400'
                  }`}
                >
                  Dairy / Fishery (8.5%)
                </button>
                <button
                  type="button"
                  onClick={() => { setLoanType('tractor'); setInterestRate(9.5); setTenureMonths(60); }}
                  className={`p-3 rounded-2xl font-bold border transition-all cursor-pointer ${
                    loanType === 'tractor' ? 'bg-emerald-50 border-[#075B46] text-[#075B46] shadow-2xs' : 'bg-[#FDFBF7] border-[#E8E1D5] text-[#555555] hover:border-gray-400'
                  }`}
                >
                  Tractor / Agri Machinery (9.5%)
                </button>
              </div>
            </div>

            {/* Principal Slider */}
            <div className="space-y-2">
              <div className="flex justify-between font-bold">
                <span className="text-[#555555]">Loan Amount:</span>
                <span className="text-[#075B46] text-sm font-extrabold">₹{principal.toLocaleString('en-IN')}</span>
              </div>
              <input
                type="range"
                min="10000"
                max="500000"
                step="5000"
                value={principal}
                onChange={(e) => setPrincipal(parseInt(e.target.value))}
                className="w-full accent-[#075B46]"
              />
            </div>

            {/* Tenure Slider */}
            <div className="space-y-2">
              <div className="flex justify-between font-bold">
                <span className="text-[#555555]">Tenure:</span>
                <span className="text-[#075B46] text-sm font-extrabold">{tenureMonths} Months ({tenureMonths / 12} Years)</span>
              </div>
              <input
                type="range"
                min="6"
                max="60"
                step="6"
                value={tenureMonths}
                onChange={(e) => setTenureMonths(parseInt(e.target.value))}
                className="w-full accent-[#075B46]"
              />
            </div>

            {loanType === 'kcc' && (
              <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 text-[11px] text-amber-950 flex items-start gap-2.5">
                <Percent className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <p>
                  <strong>3% Prompt Repayment Incentive (PRI):</strong> Base rate is 7%. When you repay within 12 months, the Central Govt provides a 3% interest subvention, making the <strong>effective interest rate only 4.0%</strong>.
                </p>
              </div>
            )}
          </div>

          {/* Results Display */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#FDFBF7] to-emerald-50/70 rounded-3xl p-6 sm:p-7 border border-[#E8E1D5] space-y-4 text-center">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
              Estimated Monthly EMI
            </span>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#075B46]">
              ₹{emi.toLocaleString('en-IN')}
            </div>
            <span className="text-xs font-bold text-[#075B46] block bg-white/80 py-1 px-3 rounded-full border border-emerald-200 inline-block">
              Effective Annual Interest: {effectiveRate}%
            </span>

            <div className="pt-4 border-t border-[#E8E1D5] space-y-2 text-xs text-left">
              <div className="flex justify-between">
                <span className="text-gray-600">Principal:</span>
                <span className="font-bold text-[#333333]">₹{principal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Interest:</span>
                <span className="font-bold text-amber-900">₹{totalInterest.toLocaleString('en-IN')}</span>
              </div>
              {subventionSavings > 0 && (
                <div className="flex justify-between text-[#075B46] font-bold">
                  <span>Govt Interest Subsidy Savings:</span>
                  <span>-₹{subventionSavings.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between pt-2 border-t border-[#E8E1D5] font-extrabold text-sm text-[#333333]">
                <span>Total Amount:</span>
                <span>₹{totalRepayment.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Savings Scheme Comparison */}
      <section className="space-y-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-900 text-xs font-bold border border-amber-200">
            <PiggyBank className="w-3.5 h-3.5" />
            <span>Savings & Deposit Comparator</span>
          </div>
          <h2 className="text-xl font-bold text-[#333333]">
            Compare Deposit Returns for Rural Members
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="bg-white rounded-3xl p-6 border border-[#075B46]/30 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-[#075B46] border border-emerald-200">
                PACS Fixed Deposit
              </span>
              <span className="text-sm font-black text-[#075B46]">7.50% - 8.25%</span>
            </div>
            <h3 className="text-base font-extrabold text-[#333333]">PACS Term Deposit Account</h3>
            <p className="text-xs text-gray-600 leading-relaxed">
              Highest local interest rate for cooperative society members. Funds reinvested directly into village farming credit.
            </p>
            <ul className="text-[11px] text-gray-700 space-y-1.5 pt-1">
              <li>✓ Loan facility up to 90% against FD</li>
              <li>✓ Zero penalty on farm distress withdrawal</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-[#E8E1D5] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                Post Office TD
              </span>
              <span className="text-sm font-black text-blue-900">7.10% - 7.50%</span>
            </div>
            <h3 className="text-base font-extrabold text-[#333333]">Post Office Time Deposit</h3>
            <p className="text-xs text-gray-600 leading-relaxed">
              100% sovereign government safety. Available in every village branch with senior citizen benefits.
            </p>
            <ul className="text-[11px] text-gray-700 space-y-1.5 pt-1">
              <li>✓ Government of India guaranteed</li>
              <li>✓ Section 80C tax benefits on 5-year TD</li>
            </ul>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-[#E8E1D5] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5]">
                Commercial Bank FD
              </span>
              <span className="text-sm font-black text-[#333333]">6.80% - 7.20%</span>
            </div>
            <h3 className="text-base font-extrabold text-[#333333]">Commercial Bank Fixed Deposit</h3>
            <p className="text-xs text-gray-600 leading-relaxed">
              Standard bank deposit. Requires net banking or branch visits to nearby tehsil/town.
            </p>
            <ul className="text-[11px] text-gray-700 space-y-1.5 pt-1">
              <li>✓ DICGC insurance up to ₹5,00,000</li>
              <li>✓ Mobile app integration</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Credit Score (CIBIL) Rural Explainer */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="space-y-1">
          <span className="text-xs font-bold text-[#FF9933] uppercase tracking-wider">Plain Language Guide</span>
          <h2 className="text-xl font-bold text-[#333333]">
            What is a Credit Score and How to Improve It?
          </h2>
          <p className="text-xs text-gray-500">
            A credit score ranges from 300 to 900. A score above 750 ensures instant loan approval without collateral.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-2">
          <div className="p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <span className="font-bold text-[#075B46] block text-sm">1. Timely KCC Renewal</span>
            <p className="text-gray-600 leading-relaxed">
              Deposit full loan amount into KCC account within 12 months after harvest and renew. This boosts your score by 50+ points.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <span className="font-bold text-amber-900 block text-sm">2. Avoid Informal Moneylenders</span>
            <p className="text-gray-600 leading-relaxed">
              Informal loans do not build credit history. Always borrow from PACS or cooperative banks with official receipts.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <span className="font-bold text-blue-900 block text-sm">3. Caution when Guarantor</span>
            <p className="text-gray-600 leading-relaxed">
              If the primary borrower defaults, the guarantor's credit score is also penalized. Guarantee responsibly.
            </p>
          </div>
        </div>
      </section>

      {/* SHG (Self Help Group) Formation Guide */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-50 text-purple-900 text-xs font-bold border border-purple-200">
            <Users className="w-3.5 h-3.5" />
            <span>Women's Self-Help Group (SHG) Formation Guide</span>
          </div>
          <h2 className="text-xl font-bold text-[#333333]">
            5 Simple Steps to Form a Village SHG & Get Bank Loan
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
          <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-1.5">
            <span className="w-7 h-7 rounded-full bg-purple-700 text-white font-bold text-xs flex items-center justify-center">1</span>
            <h4 className="font-bold text-[#333333]">Group of 10-20 Women</h4>
            <p className="text-[11px] text-gray-500">Unite women with similar socioeconomic backgrounds.</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-1.5">
            <span className="w-7 h-7 rounded-full bg-purple-700 text-white font-bold text-xs flex items-center justify-center">2</span>
            <h4 className="font-bold text-[#333333]">Regular Weekly Savings</h4>
            <p className="text-[11px] text-gray-500">Contribute ₹50-₹100 per member weekly into common pool.</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-1.5">
            <span className="w-7 h-7 rounded-full bg-purple-700 text-white font-bold text-xs flex items-center justify-center">3</span>
            <h4 className="font-bold text-[#333333]">Open Bank/PACS Account</h4>
            <p className="text-[11px] text-gray-500">Operate savings account with President and Secretary signatures.</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-1.5">
            <span className="w-7 h-7 rounded-full bg-purple-700 text-white font-bold text-xs flex items-center justify-center">4</span>
            <h4 className="font-bold text-[#333333]">Revolving Fund (RF)</h4>
            <p className="text-[11px] text-gray-500">Receive ₹15,000 grant under NRLM scheme.</p>
          </div>

          <div className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-1.5">
            <span className="w-7 h-7 rounded-full bg-[#075B46] text-white font-bold text-xs flex items-center justify-center">5</span>
            <h4 className="font-bold text-[#333333]">Bank Credit Linkage</h4>
            <p className="text-[11px] text-gray-500">Eligible for 1:4 leverage collateral-free loan of ₹1-5 Lakhs.</p>
          </div>
        </div>
      </section>
    </div>
  );
};
