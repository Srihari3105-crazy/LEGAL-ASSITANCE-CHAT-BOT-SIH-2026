import React, { useState } from 'react';
import { PageId, LanguageCode, LawItem } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { COOPERATIVE_LAWS } from '../data/mockData';
import {
  Scale,
  Search,
  BookOpen,
  Filter,
  Sparkles,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  FileCheck,
  Building,
  CheckCircle2,
  ExternalLink,
  ArrowRight
} from 'lucide-react';

interface LawsPageProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const LawsPage: React.FC<LawsPageProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedLawId, setExpandedLawId] = useState<string | null>('law-1');
  const [comparisonStateA, setComparisonStateA] = useState<string>('Maharashtra');
  const [comparisonStateB, setComparisonStateB] = useState<string>('Madhya Pradesh');

  const CATEGORIES = [
    'All',
    'MSCS Act 2002',
    'MSCS Amendment 2023',
    'Model PACS Bye-Laws',
    'State Cooperative Acts',
    'National Cooperative Policy',
    'Member Rights & Duties'
  ];

  const STATE_RULES: Record<string, { election: string; womenSeats: string; audit: string; deemedMembership: string; ombudsman: string }> = {
    'Maharashtra': {
      election: 'State Cooperative Election Authority (SCEA) conducts board elections.',
      womenSeats: 'Mandatory 2 women seats on Managing Committee.',
      audit: 'Annual audit by approved panel chartered accountants within 4 months of year end.',
      deemedMembership: 'Deemed admitted if no refusal communicated in 60 days.',
      ombudsman: 'Cooperative Appellate Court & District Registrar Grievance Cell.'
    },
    'Madhya Pradesh': {
      election: 'MP State Cooperative Election Commission supervises all PACS and Apex banks.',
      womenSeats: 'Minimum 2 women directors compulsory.',
      audit: 'Concurrent departmental and statutory audit mandatory for computerized PACS.',
      deemedMembership: 'Deemed membership within 45 days of receipt of completed application.',
      ombudsman: 'Registrar Cooperative Societies Lok Adalat & Online Portal.'
    },
    'Gujarat': {
      election: 'Dedicated Cooperative Election Officer appointed by State Govt.',
      womenSeats: '2 seats reserved for women and 1 for SC/ST.',
      audit: 'Special audit cell under Gujarat Cooperative Societies Act.',
      deemedMembership: 'Deemed approved within 60 days of submission.',
      ombudsman: 'Board of Nominees and Cooperative Tribunal.'
    },
    'Uttar Pradesh': {
      election: 'UP State Cooperative Election Commission oversees direct PACS voter list.',
      womenSeats: '2 reserved seats for women in all primary agricultural societies.',
      audit: 'Internal inspection every 6 months + Statutory annual audit.',
      deemedMembership: 'Deemed membership in 30 days under Model Bye-Laws convergence.',
      ombudsman: 'Cooperative Ombudsman & Samadhan Portal.'
    },
    'Tamil Nadu': {
      election: 'TN Cooperative Societies Election Commission conducts 5-year elections.',
      womenSeats: '30% reservation for women in management committees.',
      audit: 'Director of Cooperative Audit independently examines balance sheets.',
      deemedMembership: 'Membership confirmed within 30 days of land verification.',
      ombudsman: 'Circle Deputy Registrar Grievance Days every month.'
    }
  };

  const filteredLaws = COOPERATIVE_LAWS.filter((law) => {
    const matchesCategory = selectedCategory === 'All' || law.category === selectedCategory;
    const matchesSearch = 
      law.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.titleHi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.section.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.act.toLowerCase().includes(searchQuery.toLowerCase()) ||
      law.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Page Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <Scale className="w-3.5 h-3.5" />
              <span>{t.navLaws}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featureLawsTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featureLawsDesc}
            </p>
          </div>

          <button
            onClick={() => onAskAI('Explain cooperative rights and laws')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs shrink-0 shadow-xs cursor-pointer transition-colors"
          >
            <Sparkles className="w-4 h-4 text-[#FF9933]" />
            <span>{t.askMitra}</span>
          </button>
        </div>

        {/* Search & Filter Controls */}
        <div className="pt-2 flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`${t.search}...`}
              className="w-full pl-11 pr-4 py-3 text-xs sm:text-sm bg-[#FDFBF7] border border-[#E8E1D5] text-[#333333] rounded-full focus:outline-hidden focus:border-[#075B46] focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#075B46] text-white shadow-2xs'
                  : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
              }`}
            >
              {cat === 'All' ? t.all : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Laws List Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-[#333333]">
            {t.featureLawsTitle} ({filteredLaws.length})
          </h2>
          <span className="text-xs text-gray-500 font-medium">Click card to expand provisions</span>
        </div>

        {filteredLaws.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-3xl border border-[#E8E1D5] space-y-2">
            <AlertCircle className="w-8 h-8 text-amber-500 mx-auto" />
            <h3 className="text-sm font-bold text-[#333333]">No records found</h3>
            <p className="text-xs text-gray-500">Please try a different search keyword.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredLaws.map((law) => {
              const isExpanded = expandedLawId === law.id;

              return (
                <div
                  key={law.id}
                  className={`bg-white rounded-3xl border transition-all ${
                    isExpanded
                      ? 'border-[#075B46] shadow-md ring-1 ring-[#075B46]/20'
                      : 'border-[#E8E1D5] hover:border-gray-400 shadow-2xs'
                  }`}
                >
                  <div
                    onClick={() => setExpandedLawId(isExpanded ? null : law.id)}
                    className="p-5 sm:p-6 cursor-pointer flex flex-col sm:flex-row sm:items-start justify-between gap-4"
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
                          {law.section}
                        </span>
                        <span className="px-3 py-1 rounded-full bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] text-[11px] font-semibold">
                          {law.category}
                        </span>
                        <span className="text-[11px] text-gray-400 font-medium">
                          Applicability: {law.stateApplicability}
                        </span>
                      </div>

                      <h3 className="text-base sm:text-lg font-extrabold text-[#333333]">
                        {law.title}
                      </h3>
                      <p className="text-xs text-gray-500 font-medium">
                        {law.act}
                      </p>

                      <p className="text-xs sm:text-sm text-gray-600 pt-1 leading-relaxed">
                        {law.summary}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 self-start sm:self-center shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAskAI(`Explain ${law.act} - ${law.section} (${law.title})`);
                        }}
                        className="px-3.5 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-[#075B46] text-xs font-bold border border-emerald-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-[#FF9933]" />
                        <span>Ask AI</span>
                      </button>

                      <div className="p-1.5 rounded-full text-gray-400">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Section Details */}
                  {isExpanded && (
                    <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-[#E8E1D5] space-y-4 animate-in fade-in">
                      <div className="p-4 sm:p-5 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5] space-y-2">
                        <h4 className="text-xs font-bold text-[#333333] flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-[#075B46]" />
                          <span>Key Statutory Provisions:</span>
                        </h4>
                        <ul className="space-y-1.5 text-xs text-gray-600 pl-4 list-disc">
                          {law.keyProvisions.map((prov, pIdx) => (
                            <li key={pIdx} className="leading-relaxed">{prov}</li>
                          ))}
                        </ul>
                      </div>

                      {law.penalty && (
                        <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 text-xs text-rose-950 flex items-start gap-2.5">
                          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                          <div>
                            <strong className="font-bold text-rose-900">Penalty for Violation:</strong>
                            <p className="mt-0.5">{law.penalty}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* State-by-State Law Comparison Tool */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-800 text-xs font-bold border border-blue-200">
            <Building className="w-3.5 h-3.5" />
            <span>Comparative Matrix</span>
          </div>
          <h2 className="text-xl font-bold text-[#333333]">
            Compare State Cooperative Rules & Rights
          </h2>
          <p className="text-xs text-gray-500">
            Select two states below to compare election commissions, women representation quotas, audit frequencies, and deemed membership rules.
          </p>
        </div>

        {/* Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#555555]">State A:</label>
            <select
              value={comparisonStateA}
              onChange={(e) => setComparisonStateA(e.target.value)}
              className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] text-xs font-semibold text-[#333333] focus:outline-hidden"
            >
              {Object.keys(STATE_RULES).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#555555]">State B:</label>
            <select
              value={comparisonStateB}
              onChange={(e) => setComparisonStateB(e.target.value)}
              className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] text-xs font-semibold text-[#333333] focus:outline-hidden"
            >
              {Object.keys(STATE_RULES).map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto rounded-2xl border border-[#E8E1D5]">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-[#FDFBF7] border-b border-[#E8E1D5] text-[#333333]">
                <th className="p-3.5 font-bold w-1/4">Legal Parameter</th>
                <th className="p-3.5 font-bold w-3/8 text-[#075B46] bg-emerald-50/50">{comparisonStateA}</th>
                <th className="p-3.5 font-bold w-3/8 text-blue-900 bg-blue-50/50">{comparisonStateB}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E8E1D5] text-gray-700">
              <tr>
                <td className="p-3.5 font-bold bg-[#FDFBF7]/50 text-[#333333]">Election Authority & Oversight</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateA]?.election}</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateB]?.election}</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold bg-[#FDFBF7]/50 text-[#333333]">Women Reservation on Board</td>
                <td className="p-3.5 font-semibold text-[#075B46]">{STATE_RULES[comparisonStateA]?.womenSeats}</td>
                <td className="p-3.5 font-semibold text-blue-900">{STATE_RULES[comparisonStateB]?.womenSeats}</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold bg-[#FDFBF7]/50 text-[#333333]">Audit & Inspection Standards</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateA]?.audit}</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateB]?.audit}</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold bg-[#FDFBF7]/50 text-[#333333]">Deemed Membership Timeline</td>
                <td className="p-3.5 font-semibold">{STATE_RULES[comparisonStateA]?.deemedMembership}</td>
                <td className="p-3.5 font-semibold">{STATE_RULES[comparisonStateB]?.deemedMembership}</td>
              </tr>
              <tr>
                <td className="p-3.5 font-bold bg-[#FDFBF7]/50 text-[#333333]">Ombudsman & Grievance Redressal</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateA]?.ombudsman}</td>
                <td className="p-3.5">{STATE_RULES[comparisonStateB]?.ombudsman}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

