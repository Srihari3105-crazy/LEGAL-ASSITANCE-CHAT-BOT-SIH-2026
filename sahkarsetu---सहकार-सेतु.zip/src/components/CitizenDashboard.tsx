import React, { useState } from 'react';
import { PageId, LanguageCode } from '../types';
import { UI_TRANSLATIONS, SUPPORTED_LANGUAGES } from '../data/translations';
import { RECENT_CIRCULARS } from '../data/mockData';
import {
  Sparkles,
  Scale,
  Landmark,
  ShieldCheck,
  AlertCircle,
  Calculator,
  Store,
  Mic,
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  CreditCard,
  Sprout,
  Download,
  Languages,
  UserCheck
} from 'lucide-react';

interface CitizenDashboardProps {
  onNavigate?: (page: PageId) => void;
  setCurrentPage?: (page: PageId) => void;
  currentLanguage: LanguageCode;
  onAskAI?: (query: string) => void;
  setCurrentLanguage?: (lang: LanguageCode) => void;
}

export const CitizenDashboard: React.FC<CitizenDashboardProps> = ({
  onNavigate,
  setCurrentPage,
  currentLanguage,
  onAskAI,
  setCurrentLanguage
}) => {
  const navigate = onNavigate || setCurrentPage || (() => {});
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const QUICK_ACTIONS = [
    {
      id: 'chat' as PageId,
      title: t.actRightsTitle,
      desc: t.actRightsDesc,
      icon: Scale,
      color: 'bg-emerald-50 text-[#138808] border-emerald-200',
      tag: 'AI Live'
    },
    {
      id: 'schemes' as PageId,
      title: t.actSchemesTitle,
      desc: t.actSchemesDesc,
      icon: Landmark,
      color: 'bg-amber-50 text-amber-800 border-amber-200',
      tag: '5 Active'
    },
    {
      id: 'grievance' as PageId,
      title: t.actGrievanceTitle,
      desc: t.actGrievanceDesc,
      icon: AlertCircle,
      color: 'bg-rose-50 text-rose-800 border-rose-200',
      tag: '30-Day SLA'
    },
    {
      id: 'pmfby' as PageId,
      title: t.actPmfbyTitle,
      desc: t.actPmfbyDesc,
      icon: ShieldCheck,
      color: 'bg-blue-50 text-blue-800 border-blue-200',
      tag: '1.5% - 2%'
    },
    {
      id: 'pacs' as PageId,
      title: t.actPacsTitle,
      desc: t.actPacsDesc,
      icon: Store,
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      tag: 'Services'
    },
    {
      id: 'voice' as PageId,
      title: t.actVoiceTitle,
      desc: t.actVoiceDesc,
      icon: Mic,
      color: 'bg-purple-50 text-purple-800 border-purple-200',
      tag: 'Voice AI'
    }
  ];

  const ACTIVITIES = [
    {
      id: 'act-1',
      title: 'Kisan Credit Card (KCC) Limit Sanctioned',
      detail: '₹1,50,000 credit approved at 4% effective interest rate via Shrirampur PACS.',
      date: '01 Sep 2026',
      status: t.completed,
      statusColor: 'bg-emerald-100 text-emerald-800 border-emerald-300'
    },
    {
      id: 'act-2',
      title: 'Grievance #GRV-2026-9481 Hearing Notice',
      detail: 'Deputy Registrar scheduled hearing on 04 Sep 2026 regarding PACS share certificate denial.',
      date: '28 Aug 2026',
      status: t.inProgress,
      statusColor: 'bg-amber-100 text-amber-900 border-amber-300'
    },
    {
      id: 'act-3',
      title: 'PMFBY Soybean Crop Survey Surveyed',
      detail: 'District Agriculture Taskforce verified mid-season drought loss in Khasra #142/2.',
      date: '24 Aug 2026',
      status: t.verify,
      statusColor: 'bg-blue-100 text-blue-800 border-blue-300'
    },
    {
      id: 'act-4',
      title: 'Subsidized Neem Urea Quota Claimed',
      detail: '4 bags received at standard subsidized price ₹266.50/bag via biometric Aadhaar POS.',
      date: '16 Aug 2026',
      status: t.completed,
      statusColor: 'bg-slate-100 text-slate-700 border-slate-300'
    }
  ];

  const handleDownloadCircular = (title: string) => {
    setDownloadSuccess(`Downloaded official document: ${title}`);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Top Notification / Toast */}
      {downloadSuccess && (
        <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-700" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Citizen Profile & Welcome Card */}
      <section className="bg-gradient-to-br from-[#075B46] via-[#0B5D4B] to-[#043E30] text-white rounded-[32px] p-6 sm:p-8 shadow-md relative overflow-hidden border border-emerald-800/40">
        <div className="absolute right-0 top-0 w-80 h-80 bg-white/10 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#FF9933] text-white text-xs font-bold shadow-xs">
                {t.activeMember || t.active}
              </span>
              <span className="text-xs text-emerald-100 font-medium">
                {t.memberId}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {t.welcomeUser}
            </h1>

            <p className="text-xs sm:text-sm text-emerald-100/90 flex items-center gap-1.5 font-medium">
              <UserCheck className="w-4 h-4 text-amber-200" />
              <span>{t.societyLabel}</span>
            </p>

            <div className="flex flex-wrap gap-2 pt-1">
              <button 
                onClick={() => onAskAI ? onAskAI('Check my PACS dividend') : navigate('chat')}
                className="px-3 py-1.5 bg-white/15 hover:bg-white/25 border border-white/25 rounded-full text-xs text-white cursor-pointer transition-colors"
              >
                {t.askMitra}
              </button>
              <button 
                onClick={() => navigate('schemes')}
                className="px-3 py-1.5 bg-white/15 hover:bg-white/25 border border-white/25 rounded-full text-xs text-white cursor-pointer transition-colors"
              >
                {t.actSchemesTitle}
              </button>
            </div>
          </div>

          {/* Quick Member Stats */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-white/15 backdrop-blur-xs border border-white/20 rounded-2xl p-3.5 min-w-[125px]">
              <span className="text-[10px] text-emerald-200 uppercase font-bold block">{t.kccLimitTitle}</span>
              <span className="text-lg font-black text-amber-200">₹1,50,000</span>
              <span className="text-[10px] text-emerald-100 block">{t.kccRateSubtitle}</span>
            </div>

            <div className="bg-white/15 backdrop-blur-xs border border-white/20 rounded-2xl p-3.5 min-w-[125px]">
              <span className="text-[10px] text-emerald-200 uppercase font-bold block">{t.fertilizerQuotaTitle}</span>
              <span className="text-lg font-black text-white">6 / 10 Bags</span>
              <span className="text-[10px] text-emerald-100 block">{t.bagsRemainingSubtitle}</span>
            </div>

            <div className="bg-white/15 backdrop-blur-xs border border-white/20 rounded-2xl p-3.5 min-w-[125px]">
              <span className="text-[10px] text-emerald-200 uppercase font-bold block">{t.activeGrievanceTitle}</span>
              <span className="text-lg font-black text-amber-200">1 Case</span>
              <span className="text-[10px] text-emerald-100 block">{t.statutoryLeftSubtitle}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Prominent Language Bar on Dashboard */}
      {setCurrentLanguage && (
        <section className="bg-white border border-[#E8E1D5] rounded-3xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-[#333333] font-semibold">
            <Languages className="w-4 h-4 text-[#138808]" />
            <span>{t.selectLanguageLabel || t.selectLanguage}:</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {SUPPORTED_LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setCurrentLanguage(lang.code)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  currentLanguage === lang.code
                    ? 'bg-[#075B46] text-white shadow-xs font-bold'
                    : 'bg-[#FDFBF7] border border-[#E8E1D5] hover:bg-white text-[#333333]'
                }`}
              >
                {lang.nativeName}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Live Scheme Alerts Ticker / Current Status Banner */}
      <section className="bg-[#FFF8E6] border border-[#FFE7A3] rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#555555]">
        <div className="flex items-start gap-3 flex-1">
          <div className="p-2.5 rounded-xl bg-[#FF9933] text-white shrink-0">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-bold uppercase tracking-wider text-[#B38000] text-[10px]">
                {t.noticePmbyTitle}
              </span>
              <span className="text-[10px] bg-white text-[#B38000] px-2 py-0.5 rounded-full font-bold border border-[#FFE7A3]">
                {t.noticeUpdatedToday}
              </span>
            </div>
            <p className="text-[#333333] leading-relaxed text-xs">
              {t.noticePmbyText}
            </p>
          </div>
        </div>
        <button
          onClick={() => navigate('pmfby')}
          className="px-4 py-2 rounded-xl bg-[#FF9933] hover:bg-[#e68a2e] text-white font-bold text-xs shrink-0 transition-colors shadow-xs cursor-pointer"
        >
          {t.openCalculator}
        </button>
      </section>

      {/* Quick Action Tiles (6 Items) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-[#333333]">
              {t.quickActionsTitle}
            </h2>
            <p className="text-xs text-gray-500">
              {t.quickActionsSubtitle}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {QUICK_ACTIONS.map((action) => {
            const Icon = action.icon;
            return (
              <div
                key={action.id}
                onClick={() => navigate(action.id)}
                className="group bg-white rounded-3xl p-5 border border-[#E8E1D5] hover:border-[#138808] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2.5 rounded-2xl border ${action.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#FDFBF7] border border-[#E8E1D5] text-[#555555]">
                      {action.tag}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-[#333333] group-hover:text-[#138808] transition-colors">
                    {action.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                    {action.desc}
                  </p>
                </div>

                <div className="mt-4 pt-2.5 border-t border-[#E8E1D5] flex items-center justify-between text-xs font-bold text-[#138808]">
                  <span>{t.openService}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Two Column Grid: Recent Activity Timeline & Latest Cooperative Circulars */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Recent Activity Timeline */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-[#E8E1D5] shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#138808]" />
              <h2 className="text-base font-bold text-[#333333]">
                {t.recentActivity}
              </h2>
            </div>
            <span className="text-xs text-gray-400 font-semibold">{t.livePacsLog}</span>
          </div>

          <div className="space-y-3">
            {ACTIVITIES.map((act) => (
              <div
                key={act.id}
                className="p-4 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] hover:border-[#138808] transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-2"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-bold text-[#333333]">{act.title}</h3>
                    <span className="text-[10px] text-gray-400 font-medium">({act.date})</span>
                  </div>
                  <p className="text-[11px] text-[#555555] leading-relaxed">
                    {act.detail}
                  </p>
                </div>

                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border shrink-0 self-start ${act.statusColor}`}>
                  {act.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Latest Circulars & Downloads */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-[#E8E1D5] shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#FF9933]" />
              <h2 className="text-base font-bold text-[#333333]">
                {t.officialCirculars}
              </h2>
            </div>
            <span className="text-[10px] font-bold bg-[#FFF8E6] text-[#B38000] border border-[#FFE7A3] px-2 py-0.5 rounded-md">
              {t.govtOrders}
            </span>
          </div>

          <div className="space-y-3">
            {RECENT_CIRCULARS.map((circ) => (
              <div
                key={circ.id}
                className="p-3.5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] hover:border-[#138808] transition-all space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase">
                      {circ.refNo} • {circ.date}
                    </span>
                    <h3 className="text-xs font-bold text-[#333333] line-clamp-2 mt-0.5">
                      {circ.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#E8E1D5]">
                  <span className="text-[10px] text-gray-500 font-medium">
                    {circ.fileSize}
                  </span>
                  <button
                    onClick={() => handleDownloadCircular(circ.title)}
                    className="flex items-center gap-1 text-xs font-bold text-[#138808] hover:underline cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{t.downloadPdf}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
