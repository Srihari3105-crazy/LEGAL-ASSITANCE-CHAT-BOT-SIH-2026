import React, { useState } from 'react';
import { PageId, LanguageCode, PMFBYCalculation } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import {
  ShieldCheck,
  Calculator,
  CloudSun,
  AlertTriangle,
  Search,
  CheckCircle2,
  Clock,
  MapPin,
  Camera,
  FileCheck,
  ArrowRight,
  TrendingUp,
  Info,
  PhoneCall,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PMFBYPageProps {
  currentLanguage: LanguageCode;
  onAskAI: (query: string) => void;
}

export const PMFBYPage: React.FC<PMFBYPageProps> = ({
  currentLanguage,
  onAskAI
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  // Calculator Form State
  const [state, setState] = useState('Madhya Pradesh');
  const [district, setDistrict] = useState('Sehore');
  const [crop, setCrop] = useState('Soybean');
  const [season, setSeason] = useState<'Kharif' | 'Rabi' | 'Commercial / Horticultural'>('Kharif');
  const [landArea, setLandArea] = useState<number>(3.5);
  const [sumInsuredPerAcre, setSumInsuredPerAcre] = useState<number>(32000);

  // Claim Tracker State
  const [searchPolicyNo, setSearchPolicyNo] = useState('PMFBY/2026/78291');
  const [trackedClaim, setTrackedClaim] = useState<any>({
    policyNo: 'PMFBY/2026/78291',
    farmerName: 'Rameshwar Patel',
    crop: 'Soybean (Kharif 2026)',
    area: '3.5 Acres',
    lossCause: 'Inundation & Mid-season Cloudburst',
    lossDate: '12 Aug 2026',
    estimatedLoss: '65%',
    currentStage: 3, // 1: Intimated, 2: Document Verified, 3: Joint Survey Done, 4: Claim Approved & DBT
    sanctionedAmount: '₹72,800',
    dbtStatus: 'Disbursement Scheduled via PFMS to DCCB Account'
  });

  // Claim Filing simulation
  const [claimFiled, setClaimFiled] = useState(false);

  // Calculation Logic
  const farmerRatePercent = season === 'Kharif' ? 2.0 : season === 'Rabi' ? 1.5 : 5.0;
  const totalSumInsured = landArea * sumInsuredPerAcre;
  const farmerPremium = Math.round((totalSumInsured * farmerRatePercent) / 100);
  const actuarialRatePercent = 14.5; // typical market rate
  const totalPremium = Math.round((totalSumInsured * actuarialRatePercent) / 100);
  const totalSubsidy = totalPremium - farmerPremium;
  const centralSubsidy = Math.round(totalSubsidy / 2);
  const stateSubsidy = totalSubsidy - centralSubsidy;

  const handleTrackSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchPolicyNo.trim()) {
      setTrackedClaim({
        policyNo: searchPolicyNo.trim(),
        farmerName: 'Rameshwar Patel',
        crop: 'Wheat (Rabi 2026)',
        area: '2.0 Acres',
        lossCause: 'Hailstorm',
        lossDate: '24 Jan 2026',
        estimatedLoss: '45%',
        currentStage: 4,
        sanctionedAmount: '₹28,800',
        dbtStatus: 'Transferred to Aadhaar Linked Bank Account'
      });
    }
  };

  const handleSimulateClaimFile = (e: React.FormEvent) => {
    e.preventDefault();
    setClaimFiled(true);
    confetti({ particleCount: 70, spread: 50, origin: { y: 0.7 } });
    setTimeout(() => setClaimFiled(false), 3500);
  };

  return (
    <div className="space-y-8 pb-12 text-left">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-[#075B46] text-xs font-bold border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.navPMFBY}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#333333]">
              {t.featurePMFBYTitle}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500">
              {t.featurePMFBYDesc}
            </p>
          </div>

          <button
            onClick={() => onAskAI('How to file a PMFBY crop insurance claim and what is the 72-hour rule?')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs shrink-0 shadow-xs cursor-pointer transition-colors"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{t.askMitra}</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Calculator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form Controls */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-7 border border-[#E8E1D5] shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-50 text-[#075B46]">
                <Calculator className="w-5 h-5" />
              </div>
              <h2 className="text-base font-bold text-[#333333]">
                Premium Calculator
              </h2>
            </div>
            <span className="text-xs font-bold text-[#075B46] bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Kharif: 2% | Rabi: 1.5%
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* State */}
            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">State:</label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333] focus:outline-emerald-700"
              >
                <option>Madhya Pradesh</option>
                <option>Maharashtra</option>
                <option>Uttar Pradesh</option>
                <option>Punjab</option>
                <option>Gujarat</option>
                <option>Rajasthan</option>
                <option>Tamil Nadu</option>
                <option>Bihar</option>
                <option>Karnataka</option>
              </select>
            </div>

            {/* District */}
            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">District:</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333] focus:outline-emerald-700"
              >
                <option>Sehore</option>
                <option>Bhopal</option>
                <option>Indore</option>
                <option>Ujjain</option>
                <option>Vidisha</option>
                <option>Raisen</option>
              </select>
            </div>

            {/* Season */}
            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">Season:</label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value as any)}
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333] focus:outline-emerald-700"
              >
                <option value="Kharif">Kharif (2% Premium)</option>
                <option value="Rabi">Rabi (1.5% Premium)</option>
                <option value="Commercial / Horticultural">Commercial / Horticultural (5% Premium)</option>
              </select>
            </div>

            {/* Crop */}
            <div className="space-y-1.5">
              <label className="font-bold text-[#555555]">Crop:</label>
              <select
                value={crop}
                onChange={(e) => setCrop(e.target.value)}
                className="w-full p-3 rounded-2xl border border-[#E8E1D5] bg-[#FDFBF7] font-semibold text-[#333333] focus:outline-emerald-700"
              >
                <option>Soybean</option>
                <option>Paddy / Rice</option>
                <option>Wheat</option>
                <option>Cotton</option>
                <option>Mustard</option>
                <option>Gram / Chana</option>
                <option>Sugarcane</option>
              </select>
            </div>

            {/* Land Area */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <label className="font-bold text-[#555555]">Land Area:</label>
                <span className="font-bold text-[#075B46]">{landArea} Acres</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="20"
                step="0.5"
                value={landArea}
                onChange={(e) => setLandArea(parseFloat(e.target.value))}
                className="w-full accent-[#075B46]"
              />
            </div>

            {/* Sum Insured Per Acre */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <label className="font-bold text-[#555555]">Scale of Finance (Per Acre):</label>
                <span className="font-bold text-[#075B46]">₹{sumInsuredPerAcre.toLocaleString('en-IN')}</span>
              </div>
              <input
                type="range"
                min="15000"
                max="60000"
                step="1000"
                value={sumInsuredPerAcre}
                onChange={(e) => setSumInsuredPerAcre(parseInt(e.target.value))}
                className="w-full accent-[#075B46]"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Calculated Breakdown Results Card */}
        <div className="lg:col-span-5 bg-gradient-to-br from-[#075B46] via-[#0B5D4B] to-[#043E30] text-white rounded-3xl p-6 sm:p-7 border border-emerald-800/40 shadow-md space-y-4 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none"></div>

          <div className="relative z-10 space-y-3">
            <div className="flex items-center justify-between border-b border-white/15 pb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-200">
                Premium Breakdown
              </span>
              <span className="text-[10px] bg-white/20 text-white px-2.5 py-0.5 rounded-full font-bold border border-white/20">
                {season}
              </span>
            </div>

            {/* Big Farmer Share Callout */}
            <div className="p-4 bg-white/15 backdrop-blur-xs rounded-2xl border border-white/20 shadow-xs space-y-1 text-center">
              <span className="text-xs text-emerald-100 font-semibold">
                Farmer Share Payable (@ {farmerRatePercent}%)
              </span>
              <div className="text-3xl sm:text-4xl font-black text-amber-200">
                ₹{farmerPremium.toLocaleString('en-IN')}
              </div>
              <span className="text-[11px] text-emerald-200 font-bold block">
                (₹{Math.round(farmerPremium / landArea)} per acre)
              </span>
            </div>

            {/* Breakdown Table */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-white/10">
                <span className="text-emerald-100/80">Total Sum Insured:</span>
                <span className="font-bold text-white">₹{totalSumInsured.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/10">
                <span className="text-emerald-100/80">Central Subsidy (50%):</span>
                <span className="font-semibold text-amber-200">₹{centralSubsidy.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/10">
                <span className="text-emerald-100/80">State Subsidy (50%):</span>
                <span className="font-semibold text-amber-200">₹{stateSubsidy.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between py-1 text-emerald-200/70 text-[11px]">
                <span>Total Actuarial Cost (@ 14.5%):</span>
                <span>₹{totalPremium.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>

          <div className="relative z-10 pt-3 border-t border-white/15 space-y-2">
            <button
              onClick={() => {
                alert(`Policy enrolled successfully for ${landArea} acres of ${crop} at ₹${farmerPremium} premium. Reference slip generated!`);
              }}
              className="w-full py-3.5 rounded-full bg-white hover:bg-emerald-50 text-[#075B46] font-bold text-xs shadow-xs transition-colors text-center cursor-pointer"
            >
              Enroll Now (PACS Window)
            </button>
            <p className="text-[10px] text-emerald-100/80 text-center">
              Auto-debit available directly from Kisan Credit Card (KCC) account.
            </p>
          </div>
        </div>
      </div>

      {/* Claim Filing 4-Step Walkthrough */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-800 text-xs font-bold border border-rose-200">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>72-Hour Loss Reporting Workflow</span>
          </div>
          <h2 className="text-xl font-extrabold text-[#333333]">
            How to File a Crop Loss Claim within 72 Hours
          </h2>
          <p className="text-xs text-gray-500">
            Follow these 4 mandatory steps in case of hailstorm, localized flood, cloudburst, or post-harvest cyclone damage.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 sm:p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <div className="w-8 h-8 rounded-full bg-rose-600 text-white font-bold text-xs flex items-center justify-center">
              1
            </div>
            <h3 className="text-xs font-bold text-[#333333]">Intimate within 72 Hours</h3>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Call PMFBY toll-free 14447 or intimate directly through the SahkarSetu portal within 72 hours of the calamity.
            </p>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <div className="w-8 h-8 rounded-full bg-[#FF9933] text-white font-bold text-xs flex items-center justify-center">
              2
            </div>
            <h3 className="text-xs font-bold text-[#333333]">Geo-tagged Photos & Videos</h3>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Upload timestamped and location-verified photos of damaged crop to preserve immediate evidence.
            </p>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <div className="w-8 h-8 rounded-full bg-[#075B46] text-white font-bold text-xs flex items-center justify-center">
              3
            </div>
            <h3 className="text-xs font-bold text-[#333333]">Joint Field Survey</h3>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Patwari, Agriculture Extension Officer and insurance company representative complete joint survey within 10 days.
            </p>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] space-y-2">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
              4
            </div>
            <h3 className="text-xs font-bold text-[#333333]">Direct DBT Bank Transfer</h3>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Approved compensation is deposited directly into the farmer's Aadhaar-linked bank account within 30 days.
            </p>
          </div>
        </div>

        {/* Live Claim Intimation Mini-Form */}
        <div className="p-5 bg-amber-50/70 rounded-2xl border border-[#FFE7A3] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-950">
              Simulate 72-Hour Claim Intimation
            </span>
            <span className="text-[10px] text-amber-800 font-bold">Free Instant Intimation</span>
          </div>

          {claimFiled ? (
            <div className="p-3.5 bg-emerald-100 border border-emerald-300 text-[#075B46] rounded-2xl text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#075B46] shrink-0" />
              <span>Claim intimation recorded successfully! Claim Reference ID: <strong>CLM-2026-9812</strong></span>
            </div>
          ) : (
            <form onSubmit={handleSimulateClaimFile} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <input
                type="text"
                placeholder="Khasra / Survey No"
                defaultValue="Khasra #142/2 (Sehore)"
                required
                className="p-3 rounded-2xl border border-[#E8E1D5] bg-white text-[#333333]"
              />
              <select className="p-3 rounded-2xl border border-[#E8E1D5] bg-white font-medium text-[#333333]">
                <option>Inundation / Cloudburst</option>
                <option>Hailstorm</option>
                <option>Pest Infestation</option>
                <option>Drought</option>
              </select>
              <button
                type="submit"
                className="py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-2xl transition-colors cursor-pointer"
              >
                Submit 72h Claim
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Claim Status Tracker Mockup */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E1D5] shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E8E1D5] pb-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46]">Real-time Tracking</span>
            <h2 className="text-xl font-extrabold text-[#333333]">
              PMFBY Claim Status Tracker
            </h2>
          </div>

          <form onSubmit={handleTrackSearch} className="flex items-center gap-2">
            <input
              type="text"
              value={searchPolicyNo}
              onChange={(e) => setSearchPolicyNo(e.target.value)}
              placeholder="Policy or Application No..."
              className="p-2.5 px-3.5 rounded-full border border-[#E8E1D5] bg-[#FDFBF7] text-xs font-semibold text-[#333333] w-52 focus:outline-emerald-700"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs cursor-pointer transition-colors"
            >
              {t.trackStatus}
            </button>
          </form>
        </div>

        {trackedClaim && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
                <span className="text-[10px] text-gray-500 block">Policy / Application:</span>
                <span className="font-bold text-[#333333]">{trackedClaim.policyNo}</span>
              </div>
              <div className="p-3.5 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
                <span className="text-[10px] text-gray-500 block">Farmer Name:</span>
                <span className="font-bold text-[#333333]">{trackedClaim.farmerName}</span>
              </div>
              <div className="p-3.5 bg-[#FDFBF7] rounded-2xl border border-[#E8E1D5]">
                <span className="text-[10px] text-gray-500 block">Loss Cause & Area:</span>
                <span className="font-bold text-[#333333]">{trackedClaim.lossCause}</span>
              </div>
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200">
                <span className="text-[10px] text-[#075B46] block font-bold">Sanctioned Amount:</span>
                <span className="text-base font-black text-[#075B46]">{trackedClaim.sanctionedAmount}</span>
              </div>
            </div>

            {/* Stepper */}
            <div className="pt-2">
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {['Intimated', 'Verified', 'Survey Done', 'DBT Paid'].map((step, sIdx) => {
                  const isDone = trackedClaim.currentStage > sIdx;
                  const isCurrent = trackedClaim.currentStage === sIdx + 1;

                  return (
                    <div key={sIdx} className="space-y-2">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          isDone
                            ? 'bg-[#075B46]'
                            : isCurrent
                            ? 'bg-[#FF9933] animate-pulse'
                            : 'bg-stone-200'
                        }`}
                      ></div>
                      <span className={`text-[11px] font-semibold block ${isDone ? 'text-[#075B46]' : isCurrent ? 'text-amber-800 font-bold' : 'text-gray-400'}`}>
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] text-xs text-[#555555] flex items-center justify-between">
              <span>Current Status: <strong className="text-[#333333]">{trackedClaim.dbtStatus}</strong></span>
              <span className="text-[#075B46] font-bold">Aadhaar PFMS DBT Active</span>
            </div>
          </div>
        )}
      </section>

      {/* Weather & Advisory Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 bg-white rounded-3xl border border-[#E8E1D5] shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-[#075B46] font-bold text-xs">
            <CloudSun className="w-4 h-4" />
            <span>Weather Outlook</span>
          </div>
          <p className="text-xs text-gray-600 leading-relaxed">
            Light to moderate rainfall expected in Sehore and Malwa region over the next 48 hours. Ensure adequate field drainage.
          </p>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-[#E8E1D5] shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-amber-700 font-bold text-xs">
            <AlertTriangle className="w-4 h-4" />
            <span>Pest Alert</span>
          </div>
          <p className="text-xs text-gray-600 leading-relaxed">
            For prevention of semilooper and tobacco caterpillar in soybean, use recommended organic neem oil spray or chlorantraniliprole.
          </p>
        </div>

        <div className="p-5 bg-white rounded-3xl border border-[#E8E1D5] shadow-2xs space-y-2">
          <div className="flex items-center gap-2 text-[#075B46] font-bold text-xs">
            <PhoneCall className="w-4 h-4" />
            <span>Farmer Helpline</span>
          </div>
          <p className="text-xs text-gray-600 leading-relaxed">
            Toll-free National Crop Insurance Helpline: <strong className="text-[#075B46]">14447</strong> for direct agriculture expert support.
          </p>
        </div>
      </section>
    </div>
  );
};
