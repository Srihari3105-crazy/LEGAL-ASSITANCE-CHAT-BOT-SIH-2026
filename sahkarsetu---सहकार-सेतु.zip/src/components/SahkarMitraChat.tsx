import React, { useState, useRef, useEffect } from 'react';
import { LanguageCode, ChatMessage } from '../types';
import { UI_TRANSLATIONS, SUPPORTED_LANGUAGES } from '../data/translations';
import { INITIAL_AI_CHAT_MESSAGES, SAMPLE_AI_RESPONSES } from '../data/mockData';
import {
  Sparkles,
  Send,
  Mic,
  Paperclip,
  Volume2,
  VolumeX,
  Languages,
  BookOpen,
  CheckCircle2,
  FileCheck,
  RotateCcw,
  Scale,
  Copy,
  Check,
  AlertCircle,
  HelpCircle
} from 'lucide-react';

interface SahkarMitraChatProps {
  currentLanguage: LanguageCode;
  setCurrentLanguage: (lang: LanguageCode) => void;
  onNavigateToGrievance?: () => void;
  onNavigateToPmfby?: () => void;
  initialQuery?: string;
}

export const SahkarMitraChat: React.FC<SahkarMitraChatProps> = ({
  currentLanguage,
  setCurrentLanguage,
  onNavigateToGrievance,
  onNavigateToPmfby,
  initialQuery
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_AI_CHAT_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [attachedFile, setAttachedFile] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialQuery) {
      handleSendMessage(initialQuery);
    }
  }, [initialQuery]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const SUGGESTED_CHIPS = [
    { label: 'What are my rights as a cooperative member?', labelHi: 'सहकारी सदस्य के रूप में मेरे क्या अधिकार हैं?', key: 'rights' },
    { label: 'How do I file a complaint against my PACS?', labelHi: 'पैक्स (PACS) के खिलाफ शिकायत कैसे दर्ज करें?', key: 'complaint' },
    { label: 'Am I eligible for PMFBY crop insurance?', labelHi: 'क्या मैं PMFBY फसल बीमा के लिए पात्र हूँ?', key: 'pmfby' },
    { label: 'Explain cooperative election rules 2023.', labelHi: 'सहकारी चुनाव नियम 2023 आसान शब्दों में समझाएं।', key: 'election' }
  ];

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      language: currentLanguage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setAttachedFile(null);
    setIsTyping(true);

    // Simulate smart AI legal analysis
    setTimeout(() => {
      let responseKey = 'rights';
      const lower = text.toLowerCase();
      if (lower.includes('शिकायत') || lower.includes('complaint') || lower.includes('pacs') || lower.includes('dispute') || lower.includes('मना')) {
        responseKey = 'complaint';
      } else if (lower.includes('pmfby') || lower.includes('बीमा') || lower.includes('insurance') || lower.includes('crop') || lower.includes('premium')) {
        responseKey = 'pmfby';
      } else if (lower.includes('election') || lower.includes('चुनाव') || lower.includes('vote') || lower.includes('director') || lower.includes('निर्वाचन')) {
        responseKey = 'election';
      }

      const sample = SAMPLE_AI_RESPONSES[responseKey] || SAMPLE_AI_RESPONSES.rights;

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: currentLanguage === 'hi' ? sample.text : (
          responseKey === 'complaint'
            ? `Under Section 84 of the MSCS Act 2002 and Model Bye-laws 2023, every cooperative member has statutory rights to fair service.\n\n1. You can submit a written representation to the PACS Managing Committee.\n2. If unresolved within 15 days, escalate directly to the Cooperative Ombudsman via our Grievance Portal.\n3. The Ombudsman is bound by a 30-day statutory resolution timeline.`
            : responseKey === 'pmfby'
            ? `Under Pradhan Mantri Fasal Bima Yojana (PMFBY):\n\n• Farmers pay only 1.5% premium for Rabi crops and 2% for Kharif crops.\n• Localized calamity losses (such as hailstorms or inundation) must be intimated within 72 hours via the PMFBY portal or helpline 1800-180-1551.\n• Claims are verified through satellite assessment and credited directly to Aadhaar-linked accounts.`
            : responseKey === 'election'
            ? `Under the MSCS (Amendment) Act 2023 & Cooperative Election Authority:\n\n• Elections for the Board of Directors must be held every 5 years by the independent Cooperative Election Authority.\n• Active members who attended at least 3 general body meetings and utilized minimum services hold full voting rights.\n• One-third seats are statutorily reserved for women, and one seat for SC/ST members.`
            : `As a recognized member of a Primary Agricultural Credit Society (PACS):\n\n• You have the right to inspect audited annual financial statements and voter lists.\n• You are entitled to subsidized fertilizers, quality seeds, and KCC crop loans at 4% effective interest rate with prompt repayment subvention.\n• In case of arbitrary rejection, you can appeal directly to the District Registrar.`
        ),
        language: currentLanguage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        citations: sample.citations,
        confidence: sample.confidence,
        suggestedActions: currentLanguage === 'hi' ? sample.suggestedActions : [
          'File Official Grievance',
          'Calculate Crop Insurance',
          'Read Cooperative Acts'
        ]
      };

      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 900);
  };

  const handleMicClick = () => {
    if (isRecording) {
      setIsRecording(false);
      handleSendMessage(currentLanguage === 'hi' ? 'सहकारी चुनाव 2023 के नए नियम क्या हैं?' : 'What are the 2023 cooperative election rules?');
    } else {
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        setInputValue(currentLanguage === 'hi' ? 'पैक्स (PACS) में सदस्य के क्या अधिकार हैं?' : 'What are the rights of a PACS member?');
      }, 2000);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleReadAloud = (id: string, text: string) => {
    if ('speechSynthesis' in window) {
      if (speakingMessageId === id) {
        window.speechSynthesis.cancel();
        setSpeakingMessageId(null);
      } else {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text.replace(/[*#]/g, ''));
        utterance.lang = currentLanguage === 'hi' ? 'hi-IN' : 'en-IN';
        utterance.onend = () => setSpeakingMessageId(null);
        utterance.onerror = () => setSpeakingMessageId(null);
        setSpeakingMessageId(id);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFile(file.name);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-12 text-left">
      {/* Header bar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#E8E1D5] shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#075B46] to-[#0B5D4B] flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-extrabold text-[#333333]">
                {t.chatTitle}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-[#075B46] text-[10px] font-bold border border-emerald-200">
                {t.active}
              </span>
            </div>
            <p className="text-xs text-gray-500">
              {t.chatSubtitle}
            </p>
          </div>
        </div>

        {/* Language selector chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full py-1">
          {['en', 'hi', 'mr', 'bn', 'ta', 'te', 'gu', 'pa'].map((langCode) => {
            const lang = SUPPORTED_LANGUAGES.find(l => l.code === langCode);
            if (!lang) return null;
            return (
              <button
                key={lang.code}
                onClick={() => setCurrentLanguage(lang.code)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                  currentLanguage === lang.code
                    ? 'bg-[#075B46] text-white shadow-2xs'
                    : 'bg-[#FDFBF7] text-[#555555] border border-[#E8E1D5] hover:bg-white'
                }`}
              >
                {lang.nativeName}
              </button>
            );
          })}
        </div>
      </div>

      {/* Suggested Question Chips */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider px-1">
          {t.suggestedQuestions}:
        </span>
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_CHIPS.map((chip, idx) => {
            const chipText = currentLanguage === 'hi' ? chip.labelHi : chip.label;
            return (
              <button
                key={idx}
                onClick={() => handleSendMessage(chipText)}
                className="px-3.5 py-2 rounded-full bg-white hover:bg-emerald-50/70 border border-[#E8E1D5] hover:border-[#075B46] text-xs font-semibold text-[#333333] hover:text-[#075B46] transition-all shadow-2xs flex items-center gap-1.5 text-left cursor-pointer"
              >
                <span className="text-[#FF9933]">✦</span>
                <span>{chipText}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="bg-[#FAF8F5] border border-[#E8E1D5] rounded-3xl p-4 sm:p-6 min-h-[460px] max-h-[580px] overflow-y-auto space-y-4 shadow-inner">
        {messages.map((msg) => {
          const isAssistant = msg.sender === 'assistant';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isAssistant ? 'justify-start' : 'justify-end'}`}
            >
              {isAssistant && (
                <div className="w-8 h-8 rounded-full bg-[#075B46] text-white flex items-center justify-center text-xs font-bold shrink-0 mt-1 shadow-2xs">
                  AI
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[78%] rounded-3xl p-4 sm:p-5 space-y-3 ${
                  isAssistant
                    ? 'bg-white text-[#333333] border border-[#E8E1D5] shadow-xs'
                    : 'bg-[#075B46] text-white shadow-xs'
                }`}
              >
                {/* Text Content */}
                <div className="text-xs sm:text-sm leading-relaxed whitespace-pre-line font-medium">
                  {msg.text}
                </div>

                {/* Citations Card (for AI responses) */}
                {isAssistant && msg.citations && msg.citations.length > 0 && (
                  <div className="pt-3 border-t border-[#E8E1D5] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#555555] flex items-center gap-1.5">
                        <Scale className="w-3.5 h-3.5 text-[#075B46]" />
                        <span>{t.citationsLabel}:</span>
                      </span>
                      {msg.confidence && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-[#075B46] border border-emerald-200">
                          {msg.confidence}% {t.confidenceScore}
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.citations.map((cite, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-3 rounded-2xl bg-[#FDFBF7] border border-[#E8E1D5] text-[#333333] space-y-0.5"
                        >
                          <p className="text-xs font-bold text-[#333333]">{cite.act}</p>
                          <p className="text-[11px] text-[#075B46] font-bold">{cite.section} ({cite.clause})</p>
                          <p className="text-[10px] text-gray-500 truncate">{cite.title}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Suggested Action Buttons in Message */}
                {isAssistant && msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {msg.suggestedActions.map((act, aIdx) => (
                      <button
                        key={aIdx}
                        onClick={() => {
                          if (act.toLowerCase().includes('grievance') || act.includes('शिकायत')) {
                            onNavigateToGrievance?.();
                          } else if (act.toLowerCase().includes('crop') || act.includes('बीमा')) {
                            onNavigateToPmfby?.();
                          } else {
                            handleSendMessage(act);
                          }
                        }}
                        className="px-3 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-[#075B46] text-[11px] font-bold border border-emerald-200 transition-colors cursor-pointer"
                      >
                        {act} →
                      </button>
                    ))}
                  </div>
                )}

                {/* Footer Controls for message */}
                <div className="pt-1 flex items-center justify-between text-[10px] opacity-80">
                  <span>{msg.timestamp}</span>

                  {isAssistant && (
                    <div className="flex items-center gap-2.5">
                      <button
                        onClick={() => handleReadAloud(msg.id, msg.text)}
                        className="hover:text-[#075B46] transition-colors flex items-center gap-1 font-semibold cursor-pointer"
                        title={t.listenAudio}
                      >
                        {speakingMessageId === msg.id ? (
                          <VolumeX className="w-3.5 h-3.5 text-emerald-700 animate-pulse" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                        <span>{speakingMessageId === msg.id ? t.stopAudio : t.listenAudio}</span>
                      </button>

                      <button
                        onClick={() => handleCopyText(msg.id, msg.text)}
                        className="hover:text-[#075B46] transition-colors flex items-center gap-1 cursor-pointer"
                        title="Copy text"
                      >
                        {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-700" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedId === msg.id ? '✓' : 'Copy'}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {!isAssistant && (
                <div className="w-8 h-8 rounded-full bg-[#FF9933] text-white flex items-center justify-center text-xs font-bold shrink-0 mt-1 shadow-2xs">
                  ME
                </div>
              )}
            </div>
          );
        })}

        {isTyping && (
          <div className="flex gap-3 items-center">
            <div className="w-8 h-8 rounded-full bg-[#075B46] text-white flex items-center justify-center text-xs font-bold shrink-0">
              AI
            </div>
            <div className="bg-white rounded-2xl px-4 py-3 border border-[#E8E1D5] shadow-xs flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#075B46] animate-bounce"></div>
              <div className="w-2 h-2 rounded-full bg-[#FF9933] animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-2 h-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]"></div>
              <span className="text-xs text-gray-500 font-medium ml-1">{t.searching}</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box & Action Bar */}
      <div className="bg-white rounded-3xl p-3 sm:p-4 border border-[#E8E1D5] shadow-md space-y-2">
        {attachedFile && (
          <div className="p-2.5 bg-amber-50 border border-[#FFE7A3] rounded-2xl text-xs flex items-center justify-between text-amber-900">
            <span className="font-semibold flex items-center gap-1.5">
              <Paperclip className="w-3.5 h-3.5" />
              <span>Attached: {attachedFile}</span>
            </span>
            <button
              onClick={() => setAttachedFile(null)}
              className="text-rose-600 font-bold hover:underline cursor-pointer"
            >
              Remove
            </button>
          </div>
        )}

        <div className="flex items-center gap-2">
          {/* File Attachment */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
            accept=".pdf,.png,.jpg,.jpeg,.doc"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 text-gray-500 hover:text-[#075B46] hover:bg-emerald-50 rounded-2xl transition-colors cursor-pointer"
            title="Attach Document"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Voice Input Button */}
          <button
            type="button"
            onClick={handleMicClick}
            className={`p-2.5 rounded-2xl transition-all cursor-pointer ${
              isRecording
                ? 'bg-rose-500 text-white animate-pulse shadow-md'
                : 'text-[#B38000] hover:bg-[#FFF8E6]'
            }`}
            title={isRecording ? t.stopListening : t.tapToSpeak}
          >
            <Mic className="w-5 h-5" />
          </button>

          {/* Main Text Input */}
          <input
            id="chat-input-field"
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendMessage();
            }}
            placeholder={t.chatPlaceholder}
            className="flex-1 px-3 py-2 text-sm text-[#333333] placeholder:text-gray-400 bg-transparent focus:outline-hidden"
          />

          {/* Send Button */}
          <button
            id="chat-btn-send"
            type="button"
            onClick={() => handleSendMessage()}
            disabled={!inputValue.trim() && !attachedFile}
            className={`p-2.5 px-4 rounded-2xl transition-all cursor-pointer ${
              inputValue.trim() || attachedFile
                ? 'bg-[#075B46] hover:bg-[#0B5D4B] text-white shadow-xs'
                : 'bg-stone-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Legal Disclaimer Note */}
        <div className="pt-2 border-t border-[#E8E1D5] flex items-center justify-between text-[11px] text-gray-500">
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-[#B38000]" />
            <span>{t.statutoryNotice}</span>
          </div>
          <span className="font-semibold text-[#075B46]">SahkarSetu</span>
        </div>
      </div>
    </div>
  );
};
