import React, { useState } from 'react';
import { PageId, LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES, UI_TRANSLATIONS } from '../data/translations';
import { 
  Languages, 
  PhoneCall, 
  Menu, 
  X, 
  Volume2, 
  VolumeX, 
  Eye, 
  Sparkles, 
  Tv,
  Scale,
  Landmark,
  ShieldCheck,
  Store,
  GraduationCap,
  Home,
  Download
} from 'lucide-react';
import { downloadProjectZip } from '../utils/exportZip';

interface HeaderProps {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  currentLanguage: LanguageCode;
  setCurrentLanguage: (lang: LanguageCode) => void;
  kioskMode: boolean;
  setKioskMode: (enabled: boolean) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  setFontSize: (size: 'normal' | 'large' | 'xlarge') => void;
  isHighContrast: boolean;
  setIsHighContrast: (val: boolean) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  setCurrentPage,
  currentLanguage,
  setCurrentLanguage,
  kioskMode,
  setKioskMode,
  fontSize,
  setFontSize,
  isHighContrast,
  setIsHighContrast,
  mobileMenuOpen,
  setMobileMenuOpen
}) => {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  const currentLangObj = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  const handleReadAloudHeader = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
      } else {
        const textToRead = `${t.appName}. ${t.tagline}. ${t.ministryBadge}`;
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.lang = currentLanguage === 'hi' ? 'hi-IN' : 'en-IN';
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        setIsSpeaking(true);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const navItems: { id: PageId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'landing', label: t.navHome, icon: Home },
    { id: 'dashboard', label: t.services, icon: Store },
    { id: 'schemes', label: t.navSchemes, icon: Landmark },
    { id: 'grievance', label: t.navGrievance, icon: Scale },
    { id: 'pacs', label: t.navPacs, icon: Store },
    { id: 'financial', label: t.navLearn, icon: GraduationCap },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-[#E8E1D5] shadow-xs">
      {/* Top Government Tricolor Stripe */}
      <div className="h-1 w-full flex">
        <div className="flex-1 bg-[#FF9933]"></div>
        <div className="flex-1 bg-white"></div>
        <div className="flex-1 bg-[#138808]"></div>
      </div>

      {/* Official Government Top Bar */}
      <div className="bg-[#F8F5F0] border-b border-[#E8E1D5] px-3 sm:px-6 py-1 text-xs text-[#555555] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 font-medium">
          <div className="flex items-center gap-1.5 text-[#333333]">
            <span className="w-4 h-4 rounded-full bg-[#075B46] flex items-center justify-center text-[9px] text-white font-bold">
              ☸
            </span>
            <span className="font-semibold text-[#333333] truncate max-w-[280px] sm:max-w-none">{t.ministryBadge}</span>
          </div>
          <span className="hidden md:inline text-[#B38000] font-semibold px-2 py-0.5 rounded-full bg-[#FFF8E6] border border-[#FFE7A3] text-[10px]">
            SIH 2026
          </span>
        </div>

        {/* Accessibility Tools Bar */}
        <div className="flex items-center gap-2 sm:gap-3 ml-auto">
          {/* Font Resizer */}
          <div className="flex items-center bg-white border border-[#E8E1D5] rounded-full overflow-hidden text-[11px] font-semibold text-[#555555]">
            <button
              onClick={() => setFontSize('normal')}
              className={`px-2.5 py-0.5 hover:bg-[#F8F5F0] ${fontSize === 'normal' ? 'bg-[#075B46] text-white font-bold' : ''}`}
              title="Standard Font Size"
            >
              A-
            </button>
            <button
              onClick={() => setFontSize('large')}
              className={`px-2.5 py-0.5 border-x border-[#E8E1D5] hover:bg-[#F8F5F0] ${fontSize === 'large' ? 'bg-[#075B46] text-white font-bold' : ''}`}
              title="Large Font Size"
            >
              A
            </button>
            <button
              onClick={() => setFontSize('xlarge')}
              className={`px-2.5 py-0.5 hover:bg-[#F8F5F0] ${fontSize === 'xlarge' ? 'bg-[#075B46] text-white font-bold' : ''}`}
              title="Extra Large Font Size"
            >
              A+
            </button>
          </div>

          {/* High Contrast Toggle */}
          <button
            onClick={() => setIsHighContrast(!isHighContrast)}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] transition-colors ${
              isHighContrast 
                ? 'bg-amber-100 text-amber-900 border-amber-300 font-bold' 
                : 'bg-white text-[#555555] border-[#E8E1D5] hover:bg-[#F8F5F0]'
            }`}
            title={t.highContrast}
          >
            <Eye className="w-3 h-3 text-[#555555]" />
            <span className="hidden sm:inline">{t.highContrast}</span>
          </button>

          {/* Read Aloud Assist */}
          <button
            onClick={handleReadAloudHeader}
            className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] transition-colors ${
              isSpeaking 
                ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold animate-pulse' 
                : 'bg-white text-[#555555] border-[#E8E1D5] hover:bg-[#F8F5F0]'
            }`}
            title={isSpeaking ? t.stopAudio : t.screenReader}
          >
            {isSpeaking ? <VolumeX className="w-3 h-3 text-[#075B46]" /> : <Volume2 className="w-3 h-3 text-[#075B46]" />}
            <span className="hidden sm:inline">{isSpeaking ? t.stopAudio : t.screenReader}</span>
          </button>

          {/* Download Code ZIP */}
          <button
            id="btn-download-zip"
            onClick={downloadProjectZip}
            className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#075B46] text-white hover:bg-[#0B5D4B] text-[11px] font-bold shadow-xs transition-colors cursor-pointer"
            title="Download complete source code as ZIP"
          >
            <Download className="w-3 h-3 text-amber-300" />
            <span>Download ZIP</span>
          </button>

          {/* Helpline */}
          <a 
            href="tel:18001801551" 
            className="flex items-center gap-1 text-[11px] text-[#075B46] font-bold hover:underline"
            title={t.tollFree}
          >
            <PhoneCall className="w-3 h-3" />
            <span className="hidden md:inline">{t.tollFree}</span>
            <span className="md:hidden">1800-180-1551</span>
          </a>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div 
          onClick={() => setCurrentPage('landing')}
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-br from-[#075B46] to-[#0B5D4B] p-0.5 shadow-xs flex items-center justify-center text-white">
            <div className="w-full h-full rounded-[14px] flex flex-col items-center justify-center leading-none">
              <span className="text-[13px] font-black tracking-tight text-amber-200">
                SS
              </span>
              <span className="text-[7px] font-bold text-white tracking-widest uppercase">
                SETU
              </span>
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#FF9933] border-2 border-white flex items-center justify-center">
              <Sparkles className="w-2 h-2 text-white" />
            </div>
          </div>

          <div>
            <div className="flex items-baseline gap-1.5">
              <h1 className="text-xl sm:text-2xl font-black text-[#075B46] tracking-tight">
                {t.appName}
              </h1>
            </div>
            <p className="text-[10px] text-gray-500 font-medium hidden sm:block">
              {t.tagline}
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links: Home, Services, Schemes, Grievances, PACS, Learn */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#F8F5F0] p-1 rounded-full border border-[#E8E1D5]">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-white text-[#075B46] shadow-xs font-bold'
                    : 'text-[#555555] hover:text-[#075B46] hover:bg-white/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Nav Actions: Language Selector, Kiosk, Dark Green "Talk to SahkarMitra" Button */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              id="btn-lang-dropdown"
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-[#F8F5F0] hover:bg-[#E8E1D5]/60 text-[#333333] text-xs font-semibold border border-[#E8E1D5] transition-colors"
            >
              <Languages className="w-3.5 h-3.5 text-[#075B46]" />
              <span className="max-w-[70px] truncate">{currentLangObj.nativeName}</span>
              <span className="text-[9px] text-gray-400">▼</span>
            </button>

            {langMenuOpen && (
              <div 
                className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-[#E8E1D5] py-2 z-50 animate-in fade-in slide-in-from-top-2"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-3.5 py-1.5 border-b border-[#E8E1D5] text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  {t.selectLanguage} ({t.indicLanguagesCount || '12 Indic Languages'})
                </div>
                <div className="max-h-72 overflow-y-auto py-1 grid grid-cols-2 gap-1 px-1.5">
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setCurrentLanguage(lang.code);
                        setLangMenuOpen(false);
                      }}
                      className={`flex flex-col items-start px-2.5 py-2 rounded-xl text-left text-xs transition-colors ${
                        currentLanguage === lang.code 
                          ? 'bg-[#075B46] text-white font-bold' 
                          : 'text-[#333333] hover:bg-[#F8F5F0]'
                      }`}
                    >
                      <span className="font-semibold">{lang.nativeName}</span>
                      <span className={`text-[10px] font-normal ${currentLanguage === lang.code ? 'text-white/80' : 'text-gray-400'}`}>{lang.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Kiosk Mode Simulator Toggle */}
          <button
            id="btn-kiosk-toggle"
            onClick={() => setKioskMode(!kioskMode)}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-full border text-xs font-semibold transition-all ${
              kioskMode
                ? 'bg-slate-900 text-amber-300 border-slate-800'
                : 'bg-[#F8F5F0] text-[#555555] border-[#E8E1D5] hover:bg-white'
            }`}
            title="Rural PACS Touchscreen Kiosk Simulator"
          >
            <Tv className="w-3.5 h-3.5 text-[#FF9933]" />
            <span className="hidden md:inline">{t.kioskMode}</span>
          </button>

          {/* Prominent Dark Green CTA Button: Talk to SahkarMitra */}
          <button
            id="btn-chat-header"
            onClick={() => setCurrentPage('chat')}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#075B46] hover:bg-[#0B5D4B] text-white font-bold text-xs sm:text-sm shadow-sm hover:shadow-md transition-all active:scale-[0.98]"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{t.talkToMitra || t.askMitra}</span>
          </button>

          {/* Mobile Hamburger Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-full bg-[#F8F5F0] text-[#333333] hover:bg-[#E8E1D5]"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#E8E1D5] bg-white p-4 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 p-2.5 rounded-2xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#075B46] text-white'
                      : 'bg-[#F8F5F0] text-[#333333] hover:bg-[#E8E1D5]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-[#E8E1D5] flex items-center justify-between gap-2">
            <button
              onClick={() => {
                setCurrentPage('voice');
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-2 rounded-xl bg-[#FFF8E6] text-[#B38000] border border-[#FFE7A3] text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <Volume2 className="w-4 h-4" />
              <span>{t.voiceVaani}</span>
            </button>
            <button
              onClick={() => {
                downloadProjectZip();
                setMobileMenuOpen(false);
              }}
              className="py-2 px-3 rounded-xl bg-[#075B46] text-white text-xs font-bold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span>ZIP</span>
            </button>
            <button
              onClick={() => {
                setKioskMode(!kioskMode);
                setMobileMenuOpen(false);
              }}
              className="py-2 px-3 rounded-xl bg-[#F8F5F0] text-[#555555] border border-[#E8E1D5] text-xs font-semibold"
            >
              {t.kioskMode}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

