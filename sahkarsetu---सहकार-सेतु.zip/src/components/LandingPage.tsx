import React from 'react';
import { PageId, LanguageCode } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { 
  Sparkles, 
  Mic, 
  Scale, 
  Landmark, 
  ShieldCheck, 
  AlertCircle, 
  Calculator, 
  Store, 
  Tv, 
  WifiOff, 
  Languages, 
  CheckCircle2, 
  ArrowRight, 
  PhoneCall, 
  HelpCircle, 
  FileCheck2, 
  Building2, 
  Users, 
  Sprout, 
  FileText,
  BadgePercent,
  Clock,
  Check,
  ChevronRight,
  TrendingUp,
  UserCheck
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: PageId) => void;
  currentLanguage: LanguageCode;
  onAskAI?: (query: string) => void;
  onOpenKioskMode: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  currentLanguage,
  onAskAI,
  onOpenKioskMode
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  const FEATURES = [
    {
      id: 'laws' as PageId,
      title: t.featureLawsTitle,
      desc: t.featureLawsDesc,
      icon: Scale,
      tag: t.featureLawsTag,
    },
    {
      id: 'schemes' as PageId,
      title: t.featureSchemesTitle,
      desc: t.featureSchemesDesc,
      icon: Landmark,
      tag: t.featureSchemesTag,
    },
    {
      id: 'pmfby' as PageId,
      title: t.featurePmfbyTitle,
      desc: t.featurePmfbyDesc,
      icon: ShieldCheck,
      tag: t.featurePmfbyTag,
    },
    {
      id: 'voice' as PageId,
      title: t.featureVoiceTitle,
      desc: t.featureVoiceDesc,
      icon: Mic,
      tag: t.featureVoiceTag,
    },
    {
      id: 'grievance' as PageId,
      title: t.featureGrievanceTitle,
      desc: t.featureGrievanceDesc,
      icon: AlertCircle,
      tag: t.featureGrievanceTag,
    },
    {
      id: 'financial' as PageId,
      title: t.featureFinancialTitle,
      desc: t.featureFinancialDesc,
      icon: Calculator,
      tag: t.featureFinancialTag,
    }
  ];

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section: Dark Cooperative-Green Hero Panel Centered in Warm-Cream */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#075B46] via-[#0B5D4B] to-[#043E30] text-white rounded-[32px] p-6 sm:p-10 lg:p-14 shadow-xl border border-emerald-800/40">
        {/* Soft Sage & Emerald Depth Glows */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-400/15 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Subtle Background Pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px]"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Column: Headline, Description, and CTAs */}
          <div className="lg:col-span-6 xl:col-span-7 space-y-6 text-left">
            {/* Pill Label */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-xs border border-white/20 text-amber-200 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#FF9933]"></span>
              <span>{t.heroBadge}</span>
            </div>

            {/* Headline */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15]">
                {t.heroMainHeading}
              </h1>
              <p className="text-base sm:text-lg text-emerald-100/90 font-normal leading-relaxed max-w-xl">
                {t.heroMainDesc}
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="hero-btn-ask-mitra"
                onClick={() => onNavigate('chat')}
                className="flex items-center gap-2 px-6 py-3.5 rounded-full bg-white text-[#075B46] hover:bg-emerald-50 font-bold text-sm sm:text-base shadow-md transition-all active:scale-[0.98] cursor-pointer"
              >
                <span>{t.heroBtnAsk}</span>
                <ArrowRight className="w-4 h-4 text-[#075B46]" />
              </button>

              <button
                id="hero-btn-explore-services"
                onClick={() => onNavigate('dashboard')}
                className="px-5 py-3.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-semibold text-sm sm:text-base border border-white/25 transition-all cursor-pointer"
              >
                {t.heroBtnExplore}
              </button>
            </div>

            {/* Trust Highlights Strip */}
            <div className="pt-6 flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-emerald-100/80 border-t border-white/15">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF9933]" />
                <span>{t.heroStatsLaws}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF9933]" />
                <span>{t.heroStatsPacs}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#FF9933]" />
                <span>{t.heroStatsMembers}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Layered Dashboard Illustration */}
          <div className="lg:col-span-6 xl:col-span-5 relative">
            {/* Subtle background glow circle */}
            <div className="absolute -inset-4 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="relative space-y-3.5">
              {/* Card 1: Digital Cooperative Member Card */}
              <div className="bg-white/15 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/25 shadow-lg text-left">
                <div className="flex items-center justify-between pb-3 border-b border-white/15">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-white text-[#075B46] flex items-center justify-center font-black text-sm">
                      SS
                    </div>
                    <div>
                      <h2 className="text-xs font-bold text-white tracking-wide">
                        {t.profile}
                      </h2>
                      <p className="text-[10px] text-emerald-200/90 font-mono">{t.memberId}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/25 text-emerald-100 text-[10px] font-bold border border-emerald-300/30">
                    {t.active}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-3 text-[11px]">
                  <div>
                    <span className="text-emerald-200/75 block text-[10px]">{t.formApplicantName}</span>
                    <span className="font-semibold text-white">Rameshwar Patel</span>
                  </div>
                  <div>
                    <span className="text-emerald-200/75 block text-[10px]">{t.formPacsName}</span>
                    <span className="font-semibold text-white truncate block">Khargone PACS, MP</span>
                  </div>
                </div>
              </div>

              {/* Floating Cards Row 1: Scheme Eligibility & PMFBY Premium Estimate */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Floating Scheme Eligibility Card */}
                <div 
                  onClick={() => onNavigate('schemes')}
                  className="bg-white rounded-2xl p-3.5 shadow-md border border-stone-100 text-left cursor-pointer hover:shadow-lg transition-shadow group"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#075B46] flex items-center gap-1">
                      <Landmark className="w-3 h-3 text-[#075B46]" />
                      {t.eligibility}
                    </span>
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  </div>
                  <p className="text-xs font-bold text-[#333333]">
                    {t.actSchemesTitle}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-0.5">
                    ₹15,000 {t.subsidyGrant}
                  </p>
                </div>

                {/* Floating PMFBY Premium Estimate Card */}
                <div 
                  onClick={() => onNavigate('pmfby')}
                  className="bg-white rounded-2xl p-3.5 shadow-md border border-stone-100 text-left cursor-pointer hover:shadow-lg transition-shadow group"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#B38000] flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-[#FF9933]" />
                      {t.navPmfby}
                    </span>
                    <span className="text-[10px] font-bold text-[#075B46]">1.5%</span>
                  </div>
                  <p className="text-xs font-bold text-[#333333]">
                    ₹450 / {t.landAreaAcres}
                  </p>
                  <p className="text-[10px] text-gray-500 mt-0.5">
                    ₹30,000 {t.sumInsuredPerAcre}
                  </p>
                </div>
              </div>

              {/* Floating Notification Card: Grievance Status In Progress */}
              <div 
                onClick={() => onNavigate('grievance')}
                className="bg-white rounded-2xl p-3.5 shadow-md border border-stone-100 flex items-center justify-between gap-3 text-left cursor-pointer hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-50 text-[#B38000] border border-[#FFE7A3] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase text-[#555555]">
                        {t.activeGrievanceTitle}
                      </span>
                      <span className="px-2 py-0.2 rounded-full bg-amber-100 text-amber-800 text-[9px] font-bold">
                        {t.inProgress}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-[#333333] truncate">
                      {t.fertilizerQuotaTitle} • {t.statutoryLeftSubtitle}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Highlights Bar: Low-Bandwidth Offline & 12 Regional Languages */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-white border border-[#E8E1D5] rounded-3xl shadow-xs flex items-center gap-4 text-left">
          <div className="p-3 rounded-2xl bg-emerald-50 text-[#075B46] border border-emerald-100 shrink-0">
            <WifiOff className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#333333]">
              {t.onlineOffline}
            </h2>
            <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
              {t.whyCard2Desc}
            </p>
          </div>
        </div>

        <div className="p-5 bg-white border border-[#E8E1D5] rounded-3xl shadow-xs flex items-center gap-4 text-left">
          <div className="p-3 rounded-2xl bg-[#FFF8E6] text-[#B38000] border border-[#FFE7A3] shrink-0">
            <Languages className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#333333]">
              {t.indicLanguagesCount}
            </h2>
            <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
              English, हिन्दी, தமிழ், తెలుగు, বাংলা, मराठी, ગુજરાતી, ಕನ್ನಡ, മലയാളം, ਪੰਜਾਬੀ, ଓଡ଼ିଆ, اردو.
            </p>
          </div>
        </div>
      </section>

      {/* Services & Core Modules Grid */}
      <section className="space-y-6 text-left">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#075B46] uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.services}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#333333] tracking-tight">
            {t.whySahkarSetu}
          </h2>
          <p className="text-sm text-gray-500 max-w-2xl">
            {t.whySahkarSetuDesc}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.id}
                onClick={() => onNavigate(feat.id)}
                className="group bg-white rounded-3xl p-6 border border-[#E8E1D5] hover:border-[#075B46] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 rounded-2xl bg-emerald-50 text-[#075B46] border border-emerald-100 group-hover:bg-[#075B46] group-hover:text-white transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#F8F5F0] text-[#555555] border border-[#E8E1D5]">
                      {feat.tag}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#333333] group-hover:text-[#075B46] transition-colors">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-[#E8E1D5] flex items-center justify-between text-xs font-bold text-[#075B46]">
                  <span>{t.viewDetails}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Rural Touchscreen Kiosk Section */}
      <section className="bg-gradient-to-br from-[#1C2621] to-[#141C18] text-white rounded-[32px] p-6 sm:p-10 shadow-lg relative overflow-hidden border border-stone-800">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/15 text-amber-300 text-xs font-semibold border border-amber-300/30">
              <Tv className="w-3.5 h-3.5" />
              <span>{t.kioskMode}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {t.kioskBannerTitle}
            </h2>

            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed max-w-xl">
              {t.kioskBannerDesc}
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenKioskMode}
                className="px-6 py-3 rounded-full bg-[#FF9933] hover:bg-[#e68a2e] text-white font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Tv className="w-4 h-4 text-white" />
                <span>{t.launchKiosk}</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 flex justify-center">
            <div className="w-full max-w-sm bg-stone-900 p-4 rounded-3xl border-4 border-stone-700 shadow-2xl space-y-3 text-center">
              <div className="w-16 h-1 bg-stone-700 rounded-full mx-auto"></div>
              <div className="bg-white rounded-2xl p-4 text-[#333333] text-left space-y-2.5">
                <div className="flex items-center justify-between border-b border-[#E8E1D5] pb-2">
                  <span className="text-xs font-bold text-[#075B46]">{t.appName} {t.kioskMode}</span>
                  <span className="text-[10px] bg-[#FFF8E6] text-[#B38000] px-2 py-0.5 rounded-full font-bold border border-[#FFE7A3]">#042</span>
                </div>
                <p className="text-xs font-bold text-[#333333]">{t.welcomeUser}</p>
                <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold">
                  <button onClick={() => onNavigate('pmfby')} className="p-2.5 bg-emerald-50 text-[#075B46] rounded-xl border border-emerald-200 hover:bg-emerald-100 transition-colors">
                    {t.navPmfby}
                  </button>
                  <button onClick={() => onNavigate('grievance')} className="p-2.5 bg-rose-50 text-rose-800 rounded-xl border border-rose-200 hover:bg-rose-100 transition-colors">
                    {t.navGrievance}
                  </button>
                  <button onClick={() => onNavigate('laws')} className="p-2.5 bg-blue-50 text-blue-800 rounded-xl border border-blue-200 hover:bg-blue-100 transition-colors">
                    {t.navLaws}
                  </button>
                  <button onClick={() => onNavigate('voice')} className="p-2.5 bg-[#FFF8E6] text-[#B38000] rounded-xl border border-[#FFE7A3] hover:bg-[#FFF3D6] transition-colors">
                    {t.navVoice}
                  </button>
                </div>
              </div>
              <p className="text-[10px] text-stone-400">{t.kioskMode}</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

