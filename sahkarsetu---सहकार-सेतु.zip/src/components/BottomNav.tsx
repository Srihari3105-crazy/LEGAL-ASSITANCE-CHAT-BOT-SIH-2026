import React from 'react';
import { PageId, LanguageCode } from '../types';
import { UI_TRANSLATIONS } from '../data/translations';
import { 
  Home, 
  LayoutDashboard, 
  MessageSquareText, 
  Mic, 
  AlertCircle, 
  Layers 
} from 'lucide-react';

interface BottomNavProps {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  currentLanguage: LanguageCode;
  onOpenMoreMenu: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentPage,
  setCurrentPage,
  currentLanguage,
  onOpenMoreMenu
}) => {
  const t = UI_TRANSLATIONS[currentLanguage] || UI_TRANSLATIONS.en;

  const NAV_BUTTONS = [
    { id: 'landing' as PageId, label: t.navHome, icon: Home },
    { id: 'dashboard' as PageId, label: t.navDashboard, icon: LayoutDashboard },
    { id: 'chat' as PageId, label: t.askMitra, icon: MessageSquareText, highlight: true },
    { id: 'voice' as PageId, label: t.navVoice, icon: Mic },
    { id: 'grievance' as PageId, label: t.navGrievance, icon: AlertCircle },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#E8E1D5] shadow-lg px-2 py-2 flex items-center justify-around">
      {NAV_BUTTONS.map((btn) => {
        const Icon = btn.icon;
        const isActive = currentPage === btn.id;

        if (btn.highlight) {
          return (
            <button
              key={btn.id}
              onClick={() => setCurrentPage(btn.id)}
              className="relative -top-3 flex flex-col items-center justify-center p-2.5 rounded-full bg-[#075B46] text-white shadow-md border-2 border-white ring-2 ring-[#075B46]/20 cursor-pointer"
            >
              <Icon className="w-5 h-5 text-[#FF9933]" />
              <span className="text-[9px] font-bold mt-0.5">AI Mitra</span>
            </button>
          );
        }

        return (
          <button
            key={btn.id}
            onClick={() => setCurrentPage(btn.id)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-semibold transition-colors cursor-pointer ${
              isActive
                ? 'text-[#075B46] font-extrabold'
                : 'text-gray-500 hover:text-gray-900'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'text-[#075B46]' : 'text-gray-400'}`} />
            <span className="truncate max-w-[54px] mt-0.5">{btn.label}</span>
          </button>
        );
      })}

      <button
        onClick={onOpenMoreMenu}
        className="flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[10px] font-medium text-gray-500 hover:text-gray-900 cursor-pointer"
      >
        <Layers className="w-5 h-5 text-gray-400" />
        <span className="mt-0.5">{t.services}</span>
      </button>
    </nav>
  );
};
